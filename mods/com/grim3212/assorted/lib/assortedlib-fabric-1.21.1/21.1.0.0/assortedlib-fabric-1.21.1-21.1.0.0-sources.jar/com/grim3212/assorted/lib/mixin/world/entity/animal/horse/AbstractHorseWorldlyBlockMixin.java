package com.grim3212.assorted.lib.mixin.world.entity.animal.horse;

import com.grim3212.assorted.lib.core.block.IBlockSoundType;
import com.grim3212.assorted.lib.mixin.entity.EntityAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1496;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1496.class)
public abstract class AbstractHorseWorldlyBlockMixin extends class_1297 {

    public AbstractHorseWorldlyBlockMixin(final class_1299<?> entityType, final class_1937 level) {
        super(entityType, level);
    }

    @ModifyVariable(
            method = "playStepSound",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;getSoundType()Lnet/minecraft/world/level/block/SoundType;",
                    // The first call reads the block walked on; the second, snow above it, is left alone.
                    ordinal = 0
            ),
            ordinal = 0
    )
    private class_2498 assortedlib_injectGetBlockStateSoundType(final class_2498 current, class_2338 pPos, class_2680 pBlock) {
        if (!(this instanceof EntityAccessor entityAccessor))
            return current;

        if (pBlock.method_26204() instanceof IBlockSoundType extraProperties) {
            return extraProperties.getSoundType(pBlock, entityAccessor.getLevel(), pPos, this);
        }
        return current;
    }
}
