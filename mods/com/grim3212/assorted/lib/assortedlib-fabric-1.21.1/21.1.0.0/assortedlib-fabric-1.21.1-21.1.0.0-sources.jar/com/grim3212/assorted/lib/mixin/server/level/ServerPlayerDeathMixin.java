package com.grim3212.assorted.lib.mixin.server.level;

import com.grim3212.assorted.lib.events.PlayerDeathDropsEvent;
import com.grim3212.assorted.lib.platform.Services;
import net.minecraft.class_1282;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Raises {@link PlayerDeathDropsEvent} where NeoForge's LivingDeathEvent fires: past the totem, before the drops. */
@Mixin(class_3222.class)
public class ServerPlayerDeathMixin {

    @Inject(method = "die", at = @At("HEAD"))
    private void assortedlib_beforeDeathDrops(class_1282 source, CallbackInfo ci) {
        Services.EVENTS.handleEvents(new PlayerDeathDropsEvent((class_3222) (Object) this, source));
    }
}
