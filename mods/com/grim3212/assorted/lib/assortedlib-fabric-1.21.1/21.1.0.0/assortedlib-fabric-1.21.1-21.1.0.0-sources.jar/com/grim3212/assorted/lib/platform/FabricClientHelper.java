package com.grim3212.assorted.lib.platform;

import com.google.common.base.Suppliers;
import com.grim3212.assorted.lib.client.events.ClientTickHandler;
import com.grim3212.assorted.lib.client.events.HudElementHandler;
import com.grim3212.assorted.lib.client.events.LevelSubmitHandler;
import com.grim3212.assorted.lib.client.model.loader.FabricModelLoaders;
import com.grim3212.assorted.lib.client.model.loaders.IModelSpecificationLoader;
import com.grim3212.assorted.lib.client.render.ISpecialModelRendererRegistry;
import com.grim3212.assorted.lib.client.screen.LibScreenFactory;
import com.grim3212.assorted.lib.platform.services.IClientHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1087;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1921;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_322;
import net.minecraft.class_324;
import net.minecraft.class_326;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_3665;
import net.minecraft.class_3917;
import net.minecraft.class_3929;
import net.minecraft.class_3936;
import net.minecraft.class_4002;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_5272;
import net.minecraft.class_5601;
import net.minecraft.class_5607;
import net.minecraft.class_5614;
import net.minecraft.class_5616;
import net.minecraft.class_5617;
import net.minecraft.class_6395;
import net.minecraft.class_707;
import net.minecraft.class_756;
import net.minecraft.class_7775;
import net.minecraft.class_7923;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class FabricClientHelper implements IClientHelper {

    @Override
    public <T extends class_1703, S extends class_437 & class_3936<T>> void registerScreen(Supplier<class_3917<? extends T>> menuType, LibScreenFactory<T, S> factory) {
        class_3929.method_17542(menuType.get(), factory::create);
    }

    @Override
    public void addReloadListener(class_2960 identifier, class_3302 reloadListener) {
        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new FabricIdentifiedReloadListener(identifier, reloadListener));
    }

    /**
     * Fabric's builtin item renderer registry is the hook for a {@code builtin/entity} item. The
     * renderer is made on the first resource reload, once the entity models it bakes from exist, and
     * is reloaded with every later one, as vanilla reloads its own.
     */
    @Override
    public void registerSpecialModelRenderers(final Consumer<ISpecialModelRendererRegistry> register) {
        register.accept(FabricClientHelper::registerItemRenderer);
    }

    private static void registerItemRenderer(final Supplier<? extends class_1792> item, final Supplier<? extends class_756> renderer) {
        final class_1792 target = item.get();
        final Supplier<class_756> made = Suppliers.memoize(renderer::get);
        BuiltinItemRendererRegistry.INSTANCE.register(target, (stack, context, poseStack, bufferSource, light, overlay) ->
                made.get().method_3166(stack, context, poseStack, bufferSource, light, overlay));

        final class_2960 id = class_7923.field_41178.method_10221(target).method_48331("_item_renderer");
        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
            @Override
            public class_2960 getFabricId() {
                return id;
            }

            @Override
            public void method_14491(final class_3300 resourceManager) {
                made.get().method_14491(resourceManager);
            }
        });
    }

    @Override
    public <E extends class_2586> void registerBlockEntityRenderer(Supplier<? extends class_2591<? extends E>> entityType, class_5614<E> entityRendererFactory) {
        class_5616.method_32144(entityType.get(), entityRendererFactory);
    }

    @Override
    public <E extends class_1297> void registerEntityRenderer(Supplier<? extends class_1299<? extends E>> entityType, class_5617<E> entityRendererFactory) {
        EntityRendererRegistry.register(entityType.get(), entityRendererFactory);
    }

    @Override
    public void registerEntityLayer(class_5601 modelLayerLocation, Supplier<class_5607> layerDefinition) {
        EntityModelLayerRegistry.registerModelLayer(modelLayerLocation, layerDefinition::get);
    }

    @Override
    public void registerBlockColor(class_322 color, Supplier<List<class_2248>> blocks) {
        ColorProviderRegistry.BLOCK.register(color, blocks.get().toArray(new class_2248[0]));
    }

    @Override
    public void registerBlockRenderType(class_1921 renderType, Supplier<List<class_2248>> blocks) {
        BlockRenderLayerMap.INSTANCE.putBlocks(renderType, blocks.get().toArray(new class_2248[0]));
    }

    @Override
    public void registerItemColor(class_326 color, Supplier<List<? extends class_1935>> items) {
        ColorProviderRegistry.ITEM.register(color, items.get().toArray(new class_1935[0]));
    }

    @Override
    public class_324 getBlockColors() {
        return class_310.method_1551().method_1505();
    }

    @Override
    public void registerModelLoader(class_2960 name, IModelSpecificationLoader<?> modelLoader) {
        FabricModelLoaders.register(name, modelLoader);
    }

    /** {@code ItemProperties#register} is private in vanilla; Fabric API's transitive access wideners open it. */
    @Override
    public void registerItemProperty(Supplier<? extends class_1792> item, class_2960 id, class_6395 property) {
        class_5272.method_27879(item.get(), id, property);
    }

    /**
     * Vanilla's bakery hands a loader model to {@code BlockModelSpecificationMixin}, which bakes it
     * through its specification, so the baker's own bake already keeps it dynamic.
     */
    @Override
    public class_1087 bakeSpecificationModel(class_7775 baker, class_2960 modelLocation, class_3665 modelState) {
        return baker.method_45873(modelLocation, modelState);
    }

    @Override
    public void registerKeyMapping(class_304 keyMapping) {
        KeyBindingHelper.registerKeyBinding(keyMapping);
    }

    @Override
    public void registerClientTickStart(ClientTickHandler handler) {
        ClientTickEvents.START_CLIENT_TICK.register(handler::handle);
    }

    @Override
    public void registerClientTickEnd(ClientTickHandler handler) {
        ClientTickEvents.END_CLIENT_TICK.register(handler::handle);
    }

    /**
     * Fabric's HUD callback runs once the whole vanilla HUD is drawn, so the element lands above the
     * crosshair rather than straight after it.
     */
    @Override
    public void registerHudElement(class_2960 id, HudElementHandler element) {
        HudRenderCallback.EVENT.register(element::render);
    }

    /**
     * Drawn after entities into the entity buffers, which vanilla flushes with its own. The pose
     * stack starts at the camera: 1.21.1 applies the view rotation on the model view matrix.
     */
    @Override
    public void registerLevelSubmit(LevelSubmitHandler handler) {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            if (context.consumers() == null) {
                return;
            }

            final class_4587 poseStack = context.matrixStack() != null ? context.matrixStack() : new class_4587();
            handler.render(poseStack, context.consumers(), context.camera(), context.tickCounter().method_60637(false));
        });
    }

    @Override
    public <T extends class_2394> void registerParticle(Supplier<class_2396<T>> type, Function<class_4002, class_707<T>> factory) {
        ParticleFactoryRegistry.getInstance().register(type.get(), factory::apply);
    }

    @Override
    public class_1657 getClientPlayer() {
        return class_310.method_1551().field_1724;
    }
}
