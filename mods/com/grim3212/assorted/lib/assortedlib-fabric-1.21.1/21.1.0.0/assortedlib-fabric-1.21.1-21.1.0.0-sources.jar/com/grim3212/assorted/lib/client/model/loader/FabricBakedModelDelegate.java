package com.grim3212.assorted.lib.client.model.loader;

import com.grim3212.assorted.lib.client.model.baked.IDataAwareBakedModel;
import com.grim3212.assorted.lib.client.model.baked.IDelegatingBakedModel;
import com.grim3212.assorted.lib.client.model.data.IBlockModelData;
import com.grim3212.assorted.lib.core.block.IBlockEntityWithModelData;
import net.fabricmc.fabric.api.renderer.v1.Renderer;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

/**
 * Wraps an {@link IDataAwareBakedModel} so Fabric's renderer draws it with the model data of the
 * position being drawn. The data is the block entity's render data, which Fabric snapshots on the
 * main thread as it builds a chunk section ({@code BlockEntityRenderDataMixin} answers it from
 * {@link IBlockEntityWithModelData}); the block entity itself is the fallback for a view that has no
 * snapshot. Each quad is emitted with a material for the chunk layer the model asked for.
 */
public class FabricBakedModelDelegate implements class_1087, IDelegatingBakedModel {

    /** Materials are interned by the renderer, and chunk building runs on several threads. */
    private static final Map<class_1921, RenderMaterial> MATERIALS = new ConcurrentHashMap<>();

    private final class_1087 delegate;

    public FabricBakedModelDelegate(final class_1087 delegate) {
        this.delegate = delegate;
    }

    @Override
    public List<class_777> method_4707(@Nullable final class_2680 state, @Nullable final class_2350 direction, final @NotNull class_5819 random) {
        return delegate.method_4707(state, direction, random);
    }

    @Override
    public boolean method_4708() {
        return delegate.method_4708();
    }

    @Override
    public boolean method_4712() {
        return delegate.method_4712();
    }

    @Override
    public boolean method_24304() {
        return delegate.method_24304();
    }

    @Override
    public boolean method_4713() {
        return delegate.method_4713();
    }

    @Override
    public class_1058 method_4711() {
        return delegate.method_4711();
    }

    @Override
    public class_809 method_4709() {
        return delegate.method_4709();
    }

    @Override
    public class_806 method_4710() {
        return delegate.method_4710();
    }

    @Override
    public class_1087 getDelegate() {
        return delegate;
    }

    @Override
    public boolean isVanillaAdapter() {
        return false;
    }

    @Override
    public void emitBlockQuads(final class_1920 blockView, final class_2680 state, final class_2338 pos, final Supplier<class_5819> randomSupplier, final RenderContext context) {
        if (!(delegate instanceof final IDataAwareBakedModel dataAware)) {
            delegate.emitBlockQuads(blockView, state, pos, randomSupplier, context);
            return;
        }

        final IBlockModelData data = modelData(blockView, pos);
        final QuadEmitter emitter = context.getEmitter();
        for (final class_1921 renderType : dataAware.getSupportedRenderTypes(state, randomSupplier.get(), data)) {
            final RenderMaterial material = material(renderType);
            for (final class_2350 direction : class_2350.values()) {
                if (context.isFaceCulled(direction)) {
                    continue;
                }
                emit(emitter, dataAware.getQuads(state, direction, randomSupplier.get(), data, renderType), material, direction);
            }
            emit(emitter, dataAware.getQuads(state, null, randomSupplier.get(), data, renderType), material, null);
        }
    }

    /**
     * An item draws through the model its {@link class_806} resolve the stack to, which for a data
     * aware model already carries the stack's data, so this only has to draw what it is handed.
     */
    @Override
    public void emitItemQuads(final class_1799 stack, final Supplier<class_5819> randomSupplier, final RenderContext context) {
        if (!(delegate instanceof final IDataAwareBakedModel dataAware)) {
            delegate.emitItemQuads(stack, randomSupplier, context);
            return;
        }

        final QuadEmitter emitter = context.getEmitter();
        final IBlockModelData data = IBlockModelData.empty();
        for (final class_1921 renderType : dataAware.getSupportedRenderTypes(stack, false)) {
            final RenderMaterial material = material(renderType);
            for (final class_2350 direction : class_2350.values()) {
                emit(emitter, dataAware.getQuads(null, direction, randomSupplier.get(), data, renderType), material, direction);
            }
            emit(emitter, dataAware.getQuads(null, null, randomSupplier.get(), data, renderType), material, null);
        }
    }

    private static void emit(final QuadEmitter emitter, final List<class_777> quads, final RenderMaterial material, @Nullable final class_2350 cullFace) {
        for (final class_777 quad : quads) {
            emitter.fromVanilla(quad, material, cullFace);
            emitter.emit();
        }
    }

    private static RenderMaterial material(final class_1921 renderType) {
        return MATERIALS.computeIfAbsent(renderType, type -> {
            final Renderer renderer = Objects.requireNonNull(RendererAccess.INSTANCE.getRenderer(), "No Fabric renderer is present");
            return renderer.materialFinder().blendMode(BlendMode.fromRenderLayer(type)).find();
        });
    }

    private static IBlockModelData modelData(final class_1920 blockView, final class_2338 pos) {
        if (blockView.getBlockEntityRenderData(pos) instanceof IBlockModelData data) {
            return data;
        }

        final class_2586 blockEntity = blockView.method_8321(pos);
        if (blockEntity instanceof IBlockEntityWithModelData withData) {
            return withData.getBlockModelData();
        }

        return IBlockModelData.empty();
    }
}
