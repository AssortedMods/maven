package com.grim3212.assorted.lib.fluid;

import com.grim3212.assorted.lib.core.fluid.IFluidVariantHandler;
import com.grim3212.assorted.lib.platform.FabricFluidManager;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRenderHandler;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.minecraft.class_1058;
import net.minecraft.class_1723;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.function.Function;

/** Answers Fabric's render questions for a fluid whose handler is one of ours. */
public class FabricFluidVariantRenderHandlerDelegate implements FluidVariantRenderHandler {
    private final IFluidVariantHandler delegate;

    public FabricFluidVariantRenderHandlerDelegate(final IFluidVariantHandler delegate) {
        this.delegate = delegate;
    }

    /** Still and flowing sprite, from the textures the handler names, on the block atlas. */
    @Override
    public @Nullable class_1058[] getSprites(final FluidVariant fluidVariant) {
        final var information = FabricFluidManager.makeInformation(fluidVariant);
        final Optional<class_2960> still = delegate.getStillTexture(information);
        if (still.isEmpty()) {
            return FluidVariantRenderHandler.super.getSprites(fluidVariant);
        }

        final Function<class_2960, class_1058> atlas = class_310.method_1551().method_1549(class_1723.field_21668);
        final class_1058 stillSprite = atlas.apply(still.get());
        final class_1058 flowingSprite = delegate.getFlowingTexture(information).map(atlas).orElse(stillSprite);
        return new class_1058[]{stillSprite, flowingSprite};
    }

    @Override
    public int getColor(final FluidVariant fluidVariant, @Nullable final class_1920 view, @Nullable final class_2338 pos) {
        return delegate.getTintColor(FabricFluidManager.makeInformation(fluidVariant));
    }

    public IFluidVariantHandler getDelegate() {
        return delegate;
    }
}
