package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.LibConstants;
import com.grim3212.assorted.lib.conditions.PartToggles;
import com.grim3212.assorted.lib.platform.services.IWorldGenHelper;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.ModificationPhase;
import net.minecraft.class_1299;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5483;
import net.minecraft.class_6796;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public class FabricWorldGenHelper implements IWorldGenHelper {

    /** Fabric names every modification; this keeps two removals of the same feature apart. */
    private static final AtomicInteger REMOVALS = new AtomicInteger();

    @Override
    public void addFeatureToBiomes(BiomePredicate biomePredicate, class_2893.class_2895 step, class_2960 placedFeatureIdentifier) {
        BiomeModifications.addFeature(it -> PartToggles.isEnabled(placedFeatureIdentifier) && biomePredicate.test(it.getBiomeKey().method_29177(), it.getBiomeRegistryEntry()), step, class_5321.method_29179(class_7924.field_41245, placedFeatureIdentifier));
    }

    @Override
    public void removeFeatureFromBiomes(BiomePredicate biomePredicate, class_2893.class_2895 step, class_2960 placedFeatureIdentifier) {
        class_5321<class_6796> key = class_5321.method_29179(class_7924.field_41245, placedFeatureIdentifier);
        class_2960 name = class_2960.method_60655(LibConstants.MOD_ID, "remove_" + REMOVALS.getAndIncrement() + "_" + placedFeatureIdentifier.method_12836() + "_" + placedFeatureIdentifier.method_12832().replace('/', '_'));
        BiomeModifications.create(name).add(ModificationPhase.REMOVALS, it -> biomePredicate.test(it.getBiomeKey().method_29177(), it.getBiomeRegistryEntry()), context -> context.getGenerationSettings().removeFeature(step, key));
    }

    /**
     * {@code BiomeModifications#addSpawn} takes the weight as it is registered, before any config has
     * loaded, so this is the same modification with the weight read as the biomes load. It keeps the
     * name addSpawn gives it, the entity type's id, which is also the order it is applied in.
     */
    @Override
    public void addSpawnToBiomes(BiomePredicate biomePredicate, Supplier<? extends class_1299<?>> type, IntSupplier weight, int minCount, int maxCount) {
        class_1299<?> entityType = type.get();
        BiomeModifications.create(class_7923.field_41177.method_10221(entityType)).add(ModificationPhase.ADDITIONS,
                it -> PartToggles.isEnabled(class_7923.field_41177.method_10221(entityType)) && biomePredicate.test(it.getBiomeKey().method_29177(), it.getBiomeRegistryEntry()),
                context -> context.getSpawnSettings().addSpawn(entityType.method_5891(), new class_5483.class_1964(entityType, weight.getAsInt(), minCount, maxCount)));
    }
}
