package com.grim3212.assorted.lib.mixin.world.level.chunk;

import com.grim3212.assorted.lib.core.block.IBlockLightEmission;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Decides whether a block change altered the light properties at that position rather than only in
 * the abstract, which keeps a light re-check from being queued for every change involving one of
 * these blocks.
 * <p>
 * {@link class_3558#method_51561(class_1922, class_2338, class_2680, class_2680)} reads the emission
 * without its position, so an
 * {@link IBlockLightEmission} block - whose emission comes from its block entity - cannot be compared
 * honestly there. NeoForge patches vanilla to ask the position aware hook; Fabric has no such patch,
 * so the call site is redirected here, {@code setBlockState} having the position to hand.
 * {@code ProtoChunk}, the other caller, is left alone: worldgen has no block entities to ask.
 */
@Mixin(class_2818.class)
public abstract class LevelChunkMixin {

    @Shadow
    public abstract class_1937 getLevel();

    @Redirect(
            method = "setBlockState(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Z)Lnet/minecraft/world/level/block/state/BlockState;",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/lighting/LightEngine;hasDifferentLightProperties(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;)Z"))
    private boolean assortedlib_lightPropertiesDifferHere(class_1922 getter, class_2338 lightPos, class_2680 oldState, class_2680 newState, class_2338 pos, class_2680 placed, boolean isMoving) {
        if (newState == oldState) {
            return false;
        }

        // Everything but the emission is a property of the state alone, so it is compared exactly as
        // vanilla does; only the emission gains the position.
        if (newState.method_26193(getter, lightPos) != oldState.method_26193(getter, lightPos)
                || newState.method_26211()
                || oldState.method_26211()) {
            return true;
        }

        final class_1937 level = getLevel();
        return assortedlib_lightEmission(oldState, level, pos) != assortedlib_lightEmission(newState, level, pos);
    }

    private static int assortedlib_lightEmission(final class_2680 blockState, final class_1922 blockGetter, final class_2338 pos) {
        if (blockState.method_26204() instanceof IBlockLightEmission emission) {
            return emission.getLightEmission(blockState, blockGetter, pos);
        }

        return blockState.method_26213();
    }
}
