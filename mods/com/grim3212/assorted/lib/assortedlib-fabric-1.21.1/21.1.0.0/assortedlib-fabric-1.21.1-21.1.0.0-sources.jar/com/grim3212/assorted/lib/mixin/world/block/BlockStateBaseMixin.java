package com.grim3212.assorted.lib.mixin.world.block;

import com.grim3212.assorted.lib.core.block.IBlockMapColor;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Lets an {@link IBlockMapColor} block pick its map colour from its position. {@code
 * BlockStateBase} is nested in {@link class_4970}, not {@code Block}, so it is named through
 * its real owner.
 */
@Mixin(class_4970.class_4971.class)
public abstract class BlockStateBaseMixin {

    @Shadow
    public abstract class_2248 getBlock();

    @Shadow
    public abstract class_2680 asState();

    @Shadow
    @Final
    private class_3620 mapColor;


    @Inject(method = "getMapColor", at = @At("HEAD"), cancellable = true)
    public void assortedlib_getMapColor(class_1922 level, class_2338 pos, CallbackInfoReturnable<class_3620> cir) {
        if (getBlock() instanceof IBlockMapColor iBlockMapColor) {
            cir.setReturnValue(iBlockMapColor.getMapColor(asState(), level, pos, mapColor));
        }
    }

}
