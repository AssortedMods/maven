package com.grim3212.assorted.lib.client.model.loader;

import com.grim3212.assorted.lib.client.model.loaders.context.IModelBakingContext;
import java.util.Optional;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_809;

/**
 * Answers for the model json being baked, parents included: its textures, display transforms, GUI
 * light and ambient occlusion are read through vanilla's own {@link class_793} lookups, which walk
 * the resolved parent chain.
 */
public class FabricModelBakingContextDelegate implements IModelBakingContext {

    private final class_793 source;
    private final class_7775 baker;

    public FabricModelBakingContextDelegate(final class_793 source, final class_7775 baker) {
        this.source = source;
        this.baker = baker;
    }

    @Override
    public class_1100 getUnbakedModel(final class_2960 unbakedModel) {
        return this.baker.method_45872(unbakedModel);
    }

    @Override
    public Optional<class_4730> getMaterial(final String name) {
        if (this.source.method_3432(name)) {
            return Optional.of(this.source.method_24077(name));
        }

        return Optional.empty();
    }

    @Override
    public boolean isGui3d() {
        return this.source.method_24298().method_24299();
    }

    @Override
    public boolean useBlockLight() {
        return this.source.method_24298().method_24299();
    }

    @Override
    public boolean useAmbientOcclusion() {
        return this.source.method_3444();
    }

    @Override
    public class_809 getTransforms() {
        return this.source.method_3443();
    }
}
