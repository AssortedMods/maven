package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.LibConstants;
import com.grim3212.assorted.lib.conditions.LibParts;
import com.grim3212.assorted.lib.core.conditions.LibCondition;
import com.grim3212.assorted.lib.core.conditions.LibConditionProvider;
import com.grim3212.assorted.lib.platform.services.IConditionHelper;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.fabricmc.fabric.api.resource.conditions.v1.ResourceCondition;
import net.fabricmc.fabric.api.resource.conditions.v1.ResourceConditionType;
import net.fabricmc.fabric.api.resource.conditions.v1.ResourceConditions;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.class_8790;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Fabric conditions are codec based: a {@link ResourceCondition} is deserialised by the
 * {@link ResourceConditionType} registered for its id.
 */
public class FabricConditionHelper implements IConditionHelper {
    public static final class_2960 PART_ENABLED = class_2960.method_60655(LibConstants.MOD_ID, "part_enabled");

    @Override
    public void init() {
        // "item exists" / "block exists" are vanilla Fabric conditions now (registry_contains), so only
        // the part condition still needs a type of its own.
        ResourceConditions.register(PartEnabledCondition.TYPE);
    }

    /** Data is only generated on NeoForge, which writes Fabric's condition keys too. */
    @Override
    public class_8790 conditionalOutput(class_8790 output, Function<class_2960, List<LibConditionProvider>> conditions) {
        throw new UnsupportedOperationException("Assorted data is generated on NeoForge");
    }

    @Override
    public void register(class_2960 name, LibCondition condition) {
        ResourceConditions.register(new LibResourceCondition(name, condition).getType());
    }

    @Override
    public LibConditionProvider and(LibConditionProvider... values) {
        return wrap(ResourceConditions.and(Arrays.stream(values).map(FabricConditionHelper::unwrap).toArray(ResourceCondition[]::new)));
    }

    @Override
    public LibConditionProvider not(LibConditionProvider value) {
        return wrap(ResourceConditions.not(unwrap(value)));
    }

    @Override
    public LibConditionProvider or(LibConditionProvider... values) {
        return wrap(ResourceConditions.or(Arrays.stream(values).map(FabricConditionHelper::unwrap).toArray(ResourceCondition[]::new)));
    }

    @Override
    public LibConditionProvider blockExists(class_2960 block) {
        return wrap(ResourceConditions.registryContains(class_7924.field_41254, block));
    }

    @Override
    public LibConditionProvider itemExists(class_2960 item) {
        return wrap(ResourceConditions.registryContains(class_7924.field_41197, item));
    }

    @Override
    @SuppressWarnings("unchecked")
    public LibConditionProvider blockTagExists(class_6862<class_2248> tag) {
        return wrap(ResourceConditions.tagsPopulated(class_7924.field_41254, tag));
    }

    @Override
    @SuppressWarnings("unchecked")
    public LibConditionProvider itemTagExists(class_6862<class_1792> tag) {
        return wrap(ResourceConditions.tagsPopulated(class_7924.field_41197, tag));
    }

    @Override
    public LibConditionProvider modLoaded(String modId) {
        return wrap(ResourceConditions.allModsLoaded(modId));
    }

    @Override
    public LibConditionProvider partEnabled(String partId) {
        return wrap(new PartEnabledCondition(partId));
    }

    @Override
    public void registerPartCondition(String part, Supplier<Boolean> check) {
        LibParts.register(part, check);
    }

    public static LibConditionProvider wrap(ResourceCondition condition) {
        return new LibConditionWrapper(condition);
    }

    public static ResourceCondition unwrap(LibConditionProvider condition) {
        if (condition instanceof LibConditionWrapper wrapper) {
            return wrapper.condition();
        }

        throw new IllegalArgumentException("Condition " + condition.getName() + " was not created by this platform");
    }

    /**
     * A condition whose whole state is its name, so its codec is a unit codec over the single instance
     * created next to the {@link LibCondition} it delegates to.
     */
    private static class LibResourceCondition implements ResourceCondition {
        private final ResourceConditionType<LibResourceCondition> type;
        private final LibCondition condition;

        private LibResourceCondition(class_2960 id, LibCondition condition) {
            this.condition = condition;
            this.type = ResourceConditionType.create(id, MapCodec.unit(() -> this));
        }

        @Override
        public ResourceConditionType<?> getType() {
            return this.type;
        }

        @Override
        public boolean test(@Nullable class_7225.class_7874 registryLookup) {
            return this.condition.test();
        }
    }

    public record PartEnabledCondition(String part) implements ResourceCondition {
        public static final MapCodec<PartEnabledCondition> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                Codec.STRING.fieldOf("part").forGetter(PartEnabledCondition::part)
        ).apply(instance, PartEnabledCondition::new));
        public static final ResourceConditionType<PartEnabledCondition> TYPE = ResourceConditionType.create(PART_ENABLED, CODEC);

        @Override
        public ResourceConditionType<?> getType() {
            return TYPE;
        }

        @Override
        public boolean test(@Nullable class_7225.class_7874 registryLookup) {
            if (!LibParts.isRegistered(this.part)) {
                throw new IllegalArgumentException("Can't check part that doesn't exist!");
            }

            return LibParts.isEnabled(this.part);
        }
    }

    private record LibConditionWrapper(ResourceCondition condition) implements LibConditionProvider {

        @Override
        public class_2960 getName() {
            return this.condition.getType().id();
        }
    }
}
