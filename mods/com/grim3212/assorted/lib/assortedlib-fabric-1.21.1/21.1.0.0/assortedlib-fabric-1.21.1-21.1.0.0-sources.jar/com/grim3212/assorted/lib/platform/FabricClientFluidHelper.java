package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.core.fluid.FluidInformation;
import com.grim3212.assorted.lib.platform.services.IClientFluidHelper;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.minecraft.class_1047;
import net.minecraft.class_1058;
import net.minecraft.class_1723;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3611;

/**
 * Every answer comes from Fabric's {@link FluidVariantRendering}, which asks a fluid's registered
 * {@code FluidVariantRenderHandler} and falls back to its {@code FluidRenderHandler}, so our fluids
 * and foreign ones read the same source. The still sprite is index 0, the flowing one index 1.
 */
public class FabricClientFluidHelper implements IClientFluidHelper {

    @Override
    public int getFluidColor(FluidInformation fluid) {
        return FluidVariantRendering.getColor(FabricFluidManager.makeVariant(fluid));
    }

    @Override
    public class_1058 getSprite(FluidInformation fluid) {
        return sprite(fluid.fluid(), 0);
    }

    @Override
    public class_2960 getFlowingFluidTexture(final FluidInformation fluidInformation) {
        return getFlowingFluidTexture(fluidInformation.fluid());
    }

    @Override
    public class_2960 getFlowingFluidTexture(final class_3611 fluid) {
        return sprite(fluid, 1).method_45851().method_45816();
    }

    @Override
    public class_2960 getStillFluidTexture(final FluidInformation fluidInformation) {
        return getStillFluidTexture(fluidInformation.fluid());
    }

    @Override
    public class_2960 getStillFluidTexture(final class_3611 fluid) {
        return sprite(fluid, 0).method_45851().method_45816();
    }

    private static class_1058 sprite(final class_3611 fluid, final int index) {
        final class_1058[] sprites = FluidVariantRendering.getSprites(FabricFluidManager.makeVariant(new FluidInformation(fluid, 1)));
        if (sprites == null || sprites.length <= index || sprites[index] == null) {
            return class_310.method_1551().method_1549(class_1723.field_21668).apply(class_1047.method_4539());
        }
        return sprites[index];
    }
}
