package com.grim3212.assorted.lib.crafting.ingredient;

import com.grim3212.assorted.lib.core.crafting.ingredient.LibFluidIngredient;
import com.grim3212.assorted.lib.platform.Services;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredient;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredientSerializer;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class FabricFluidIngredient extends LibFluidIngredient implements CustomIngredient {

    public static final com.grim3212.assorted.lib.crafting.ingredient.FabricFluidIngredient.Serializer SERIALIZER = new com.grim3212.assorted.lib.crafting.ingredient.FabricFluidIngredient.Serializer();

    protected FabricFluidIngredient(@Nullable class_6862<class_1792> itemTag, class_6862<class_3611> fluidTag) {
        this(itemTag, fluidTag, Services.FLUIDS.getBucketAmount());
    }

    protected FabricFluidIngredient(@Nullable class_6862<class_1792> itemTag, class_6862<class_3611> fluidTag, long amount) {
        super(itemTag, fluidTag, amount);
    }

    public static FabricFluidIngredient of(@Nullable class_6862<class_1792> itemTag, class_6862<class_3611> fluidTag) {
        return new FabricFluidIngredient(itemTag, fluidTag);
    }

    public static FabricFluidIngredient of(@Nullable class_6862<class_1792> itemTag, class_6862<class_3611> fluidTag, long amount) {
        return new FabricFluidIngredient(itemTag, fluidTag, amount);
    }

    /**
     * The contained fluid is read off each stack's components, so an item match alone is never
     * enough: {@link #test(class_1799)} has to run. {@code getMatchingStacks()} is inherited from
     * {@link LibFluidIngredient} and lists the filled containers, which is what recipe viewers draw.
     */
    @Override
    public boolean requiresTesting() {
        return true;
    }

    @Override
    public CustomIngredientSerializer<?> getSerializer() {
        return SERIALIZER;
    }

    static class Serializer extends LibFluidIngredient.Serializer<FabricFluidIngredient> implements CustomIngredientSerializer<FabricFluidIngredient> {

        // The json/buffer pair the common serializer still carries is not a registration mechanism
        // anymore: Fabric asks for a MapCodec and a StreamCodec, so the same three fields are
        // described once here and both directions fall out of it.
        private static final MapCodec<FabricFluidIngredient> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                class_6862.method_40090(class_7924.field_41197).optionalFieldOf("item").forGetter(ingredient -> Optional.ofNullable(ingredient.getItemTag())),
                class_6862.method_40090(class_7924.field_41270).fieldOf("fluid").forGetter(LibFluidIngredient::getFluidTag),
                // Millibuckets in the file, as on NeoForge, so one recipe file reads the same on both.
                Codec.LONG.optionalFieldOf("amount", LibFluidIngredient.MILLIBUCKETS_PER_BUCKET)
                        .xmap(LibFluidIngredient::fromMillibuckets, LibFluidIngredient::toMillibuckets)
                        .forGetter(LibFluidIngredient::getAmount)
        ).apply(instance, com.grim3212.assorted.lib.crafting.ingredient.FabricFluidIngredient.Serializer::create));

        private static final class_9139<class_9129, FabricFluidIngredient> STREAM_CODEC = class_9139.method_56436(
                class_9135.method_56382(tagStreamCodec(class_7924.field_41197)), ingredient -> Optional.ofNullable(ingredient.getItemTag()),
                tagStreamCodec(class_7924.field_41270), LibFluidIngredient::getFluidTag,
                class_9135.field_48551, LibFluidIngredient::getAmount,
                (itemTag, fluidTag, amount) -> new FabricFluidIngredient(itemTag.orElse(null), fluidTag, amount)
        );

        /** A tag key on the wire is its id; the registry is implied by the field. */
        private static <T> class_9139<class_9129, class_6862<T>> tagStreamCodec(final class_5321<? extends class_2378<T>> registry) {
            return class_2960.field_48267.<class_9129>method_56430().method_56432(id -> class_6862.method_40092(registry, id), class_6862::comp_327);
        }

        private static FabricFluidIngredient create(final Optional<class_6862<class_1792>> itemTag, final class_6862<class_3611> fluidTag, final long amount) {
            return new FabricFluidIngredient(itemTag.orElse(null), fluidTag, amount);
        }

        @Override
        protected FabricFluidIngredient create(@Nullable class_6862 itemTag, class_6862 fluidTag, long amount) {
            return new FabricFluidIngredient(itemTag, fluidTag, amount);
        }

        @Override
        public class_2960 getIdentifier() {
            return super.getIdentifier();
        }

        @Override
        public MapCodec<FabricFluidIngredient> getCodec(boolean allowEmpty) {
            return CODEC;
        }

        @Override
        public class_9139<class_9129, FabricFluidIngredient> getPacketCodec() {
            return STREAM_CODEC;
        }
    }
}
