package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.core.network.LibPayload;
import com.grim3212.assorted.lib.platform.services.INetworkHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Every packet is a {@link class_8710} registered through {@link PayloadTypeRegistry};
 * {@link LibPayload} wraps each message, building its {@link class_9139} from the handler's
 * encoder/decoder pair, so the wire format matches NeoForge's.
 */
public class FabricNetworkHelper implements INetworkHelper {

    private static final Map<Class<?>, Registration<?>> messageHandlers = new ConcurrentHashMap<>();
    private static final List<Registration<?>> clientMessageHandlers = new ArrayList<>();

    private record Registration<MSG>(MessageHandler<MSG> handler, class_8710.class_9154<LibPayload<MSG>> type) {
    }

    @Override
    public <MSG> void register(MessageHandler<MSG> handler) {
        final class_8710.class_9154<LibPayload<MSG>> type = LibPayload.type(handler.id());
        final class_9139<class_9129, LibPayload<MSG>> codec = LibPayload.codec(type, handler.encoder(), handler.decoder());
        final Registration<MSG> registration = new Registration<>(handler, type);

        messageHandlers.put(handler.messageType(), registration);

        if (handler.side() == MessageBoundSide.CLIENT) {
            // The payload has to be declared on both sides, but only the client can receive it, and
            // the receiver is registered later from the client entrypoint.
            PayloadTypeRegistry.playS2C().register(type, codec);
            clientMessageHandlers.add(registration);
            return;
        }

        PayloadTypeRegistry.playC2S().register(type, codec);
        ServerPlayNetworking.registerGlobalReceiver(type, (payload, context) -> context.server().execute(
                () -> handler.messageConsumer().accept(payload.message(), context.player())));
    }

    public static void initializeClientHandlers() {
        for (Registration<?> registration : clientMessageHandlers) {
            registerClientReceiver(registration);
        }
    }

    private static <MSG> void registerClientReceiver(Registration<MSG> registration) {
        ClientPlayNetworking.registerGlobalReceiver(registration.type(), (payload, context) -> context.client().execute(
                () -> registration.handler().messageConsumer().accept(payload.message(), context.player())));
    }

    @SuppressWarnings("unchecked")
    private static <MSG> Registration<MSG> registrationFor(MSG toSend) {
        return (Registration<MSG>) messageHandlers.get(toSend.getClass());
    }

    @Override
    public <MSG> void sendToNearby(class_1937 world, class_2338 pos, MSG toSend) {
        if (world instanceof class_3218 serverLevel) {
            final Registration<MSG> registration = registrationFor(toSend);
            final LibPayload<MSG> payload = new LibPayload<>(registration.type(), toSend);
            PlayerLookup.around(serverLevel, pos, 64.0D).forEach(p -> ServerPlayNetworking.send(p, payload));
        }
    }

    @Override
    public <MSG> void sendToNearby(class_1937 world, class_1297 entity, MSG toSend) {
        sendToNearby(world, entity.method_24515(), toSend);
    }

    @Override
    public <MSG> void sendTo(class_1657 player, MSG toSend) {
        final Registration<MSG> registration = registrationFor(toSend);
        ServerPlayNetworking.send((class_3222) player, new LibPayload<>(registration.type(), toSend));
    }

    @Override
    public <MSG> void sendToServer(MSG toSend) {
        final Registration<MSG> registration = registrationFor(toSend);
        ClientPlayNetworking.send(new LibPayload<>(registration.type(), toSend));
    }
}
