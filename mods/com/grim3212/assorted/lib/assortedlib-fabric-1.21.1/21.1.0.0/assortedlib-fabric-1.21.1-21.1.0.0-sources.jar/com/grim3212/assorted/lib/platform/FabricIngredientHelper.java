package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.crafting.ingredient.FabricFluidIngredient;
import com.grim3212.assorted.lib.platform.services.IIngredientHelper;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredientSerializer;
import net.fabricmc.fabric.api.recipe.v1.ingredient.DefaultCustomIngredients;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import org.jetbrains.annotations.Nullable;

public class FabricIngredientHelper implements IIngredientHelper {
    @Override
    public void register() {
        CustomIngredientSerializer.register(FabricFluidIngredient.SERIALIZER);
    }

    @Override
    public class_1856 and(class_1856... ingredients) {
        // Same shape as or() and as NeoForge: an Ingredient may not be empty, and a single branch
        // is handed back as is rather than wrapped.
        if (ingredients.length == 0)
            throw new IllegalArgumentException("You must supply at least 1 ingredient for an AND!");

        return ingredients.length == 1 ? ingredients[0] : DefaultCustomIngredients.all(ingredients);
    }

    @Override
    public class_1856 or(class_1856... ingredients) {
        // An empty OR would silently match nothing, so it is rejected here, as NeoForge does.
        if (ingredients.length == 0)
            throw new IllegalArgumentException("You must supply at least 1 ingredient for an OR!");

        return ingredients.length == 1 ? ingredients[0] : DefaultCustomIngredients.any(ingredients);
    }

    @Override
    public class_1856 difference(class_1856 base, class_1856 subtracted) {
        return DefaultCustomIngredients.difference(base, subtracted);
    }

    @Override
    public class_1856 nbt(class_1799 item) {
        // Stacks carry data components rather than NBT, so the strict match is a component patch match.
        return DefaultCustomIngredients.components(item);
    }

    @Override
    public class_1856 fluid(@Nullable class_6862<class_1792> itemTagKey, class_6862<class_3611> fluidTagKey, long amount) {
        return FabricFluidIngredient.of(itemTagKey, fluidTagKey, amount).toVanilla();
    }
}
