package com.grim3212.assorted.lib.events;

import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_55;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7924;

public class FabricLootTableModificationContext implements LootTableModifyEvent.LootTableModificationContext {
    private final class_52.class_53 tableBuilder;
    private final class_7225.class_7874 registries;

    public FabricLootTableModificationContext(class_52.class_53 tableBuilder, class_7225.class_7874 registries) {
        this.tableBuilder = tableBuilder;
        this.registries = registries;
    }

    @Override
    public void addPool(class_55 pool) {
        tableBuilder.pool(pool);
    }

    @Override
    public void addPool(class_55.class_56 pool) {
        tableBuilder.method_336(pool);
    }

    @Override
    public class_6880<class_52> lootTable(class_5321<class_52> key) {
        return this.registries.method_46762(class_7924.field_50079).method_46747(key);
    }
}
