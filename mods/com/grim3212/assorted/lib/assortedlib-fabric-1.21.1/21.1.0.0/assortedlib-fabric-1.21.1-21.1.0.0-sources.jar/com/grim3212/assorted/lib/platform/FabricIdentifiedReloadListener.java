package com.grim3212.assorted.lib.platform;

import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_3695;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/** Fabric orders and names reload listeners by id, so a plain vanilla listener is registered under one. */
record FabricIdentifiedReloadListener(class_2960 id, class_3302 delegate) implements IdentifiableResourceReloadListener {

    @Override
    public class_2960 getFabricId() {
        return id;
    }

    @Override
    public CompletableFuture<Void> method_25931(class_4045 barrier, class_3300 manager, class_3695 prepareProfiler, class_3695 applyProfiler, Executor backgroundExecutor, Executor gameExecutor) {
        return delegate.method_25931(barrier, manager, prepareProfiler, applyProfiler, backgroundExecutor, gameExecutor);
    }

    @Override
    public String method_22322() {
        return delegate.method_22322();
    }
}
