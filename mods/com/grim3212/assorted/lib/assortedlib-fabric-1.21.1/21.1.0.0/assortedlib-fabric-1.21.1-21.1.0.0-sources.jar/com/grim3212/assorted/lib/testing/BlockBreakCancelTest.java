package com.grim3212.assorted.lib.testing;

import com.grim3212.assorted.lib.core.block.IBlockOnPlayerBreak;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class BlockBreakCancelTest extends class_2248 implements IBlockOnPlayerBreak {
    public BlockBreakCancelTest(class_2251 properties) {
        super(properties);
    }

    @Override
    public boolean canPlayerBreak(class_2680 state, class_1937 level, class_2338 pos, class_1657 player) {
        return !player.method_7337();
    }
}
