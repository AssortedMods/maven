package com.grim3212.assorted.lib.mixin.world.entity;

import com.grim3212.assorted.lib.core.block.IBlockExtraProperties;
import com.grim3212.assorted.lib.core.block.IBlockSoundType;
import com.grim3212.assorted.lib.core.block.effects.IBlockLandingEffects;
import com.grim3212.assorted.lib.mixin.entity.EntityAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;

@SuppressWarnings("InvalidInjectorMethodSignature")
@Mixin(class_1309.class)
public abstract class LivingEntityWorldlyBlockMixin extends class_1297 {
    public LivingEntityWorldlyBlockMixin(final class_1299<?> entityType, final class_1937 level) {
        super(entityType, level);
    }

    // The ground friction of a walk on land; travel reads Block#getFriction() once, for the block
    // below that affects movement.
    @Redirect(
            method = "travel",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/Block;getFriction()F")
    )
    private float assortedlib_rewriteFrictionValueForWorldlyBlocks(class_2248 block) {
        if (!(this instanceof EntityAccessor entityAccessor))
            return block.method_9499();

        final class_2338 pos = this.method_23314();
        final class_2680 blockState = entityAccessor.getLevel().method_8320(pos);
        if (blockState.method_26204() instanceof IBlockExtraProperties extraProperties) {
            return extraProperties.getFriction(blockState, entityAccessor.getLevel(), pos, this);
        }

        return block.method_9499();
    }


    @SuppressWarnings("InvalidInjectorMethodSignature")
    @ModifyVariable(
            method = "playBlockFallSound",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;getSoundType()Lnet/minecraft/world/level/block/SoundType;"
            ),
            ordinal = 0
    )
    private class_2498 assortedlib_injectGetBlockStateSoundType(final class_2498 current) {
        if (!(this instanceof EntityAccessor entityAccessor))
            return current;

        int i = class_3532.method_15357(this.method_23317());
        int j = class_3532.method_15357(this.method_23318() - (double) 0.2F);
        int k = class_3532.method_15357(this.method_23321());
        final class_2338 pos = new class_2338(i, j, k);
        class_2680 blockState = entityAccessor.getLevel().method_8320(pos);

        if (blockState.method_26204() instanceof IBlockSoundType extraProperties) {
            return extraProperties.getSoundType(blockState, entityAccessor.getLevel(), pos, this);
        }
        return current;
    }

    /**
     * Lets an {@link IBlockLandingEffects} block draw its own landing particles in place of vanilla's
     * burst; the rest of the fall is handled as vanilla handles it.
     */
    @Redirect(
            method = "checkFallDamage",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/level/ServerLevel;sendParticles(Lnet/minecraft/core/particles/ParticleOptions;DDDIDDDD)I"
            )
    )
    private <T extends class_2394> int assortedlib_checkFallEffects(final class_3218 level, final T particle, final double x, final double y, final double z, final int count,
                                                                         final double xOffset, final double yOffset, final double zOffset, final double speed,
                                                                         final double ya, final boolean onGround, final class_2680 onState, final class_2338 pos) {
        if (onState.method_26204() instanceof IBlockLandingEffects extraProps && extraProps.addLandingEffects(onState, level, pos, onState, (class_1309) (Object) this, count)) {
            return 0;
        }

        return level.method_14199(particle, x, y, z, count, xOffset, yOffset, zOffset, speed);
    }
}
