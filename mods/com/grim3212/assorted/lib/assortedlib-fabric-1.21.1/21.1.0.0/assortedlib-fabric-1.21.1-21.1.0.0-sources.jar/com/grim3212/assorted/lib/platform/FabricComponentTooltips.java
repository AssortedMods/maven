package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.core.item.IStackTooltipProvider;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.class_2561;
import net.minecraft.class_9331;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Draws the lines of every component handed to {@code IPlatformHelper#showComponentTooltip}. Fabric's
 * tooltip event fires once vanilla has written every line, so the lines are put back right under the
 * item's name, ahead of vanilla's own component lines, the way NeoForge places them.
 */
final class FabricComponentTooltips {

    private static final List<class_9331<? extends IStackTooltipProvider>> TYPES = new CopyOnWriteArrayList<>();
    private static boolean registered;

    private FabricComponentTooltips() {
    }

    static synchronized void show(class_9331<? extends IStackTooltipProvider> type) {
        if (!TYPES.contains(type)) {
            TYPES.add(type);
        }

        if (!registered) {
            registered = true;
            ItemTooltipCallback.EVENT.register((stack, context, flag, lines) -> {
                List<class_2561> added = new ArrayList<>();
                for (class_9331<? extends IStackTooltipProvider> shown : TYPES) {
                    IStackTooltipProvider provider = stack.method_57824(shown);
                    if (provider != null) {
                        provider.addToTooltip(context, added::add, flag, stack);
                    }
                }

                if (!added.isEmpty()) {
                    lines.addAll(Math.min(1, lines.size()), added);
                }
            });
        }
    }
}
