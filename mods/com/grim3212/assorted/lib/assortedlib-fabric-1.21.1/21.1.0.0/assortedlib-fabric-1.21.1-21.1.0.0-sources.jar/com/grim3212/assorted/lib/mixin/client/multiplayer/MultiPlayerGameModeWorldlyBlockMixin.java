package com.grim3212.assorted.lib.mixin.client.multiplayer;

import com.grim3212.assorted.lib.core.block.IBlockOnPlayerBreak;
import com.grim3212.assorted.lib.events.EntityInteractEvent;
import com.grim3212.assorted.lib.platform.Services;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import com.grim3212.assorted.lib.core.block.IBlockSoundType;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public abstract class MultiPlayerGameModeWorldlyBlockMixin {

    @Shadow
    @Final
    private class_310 minecraft;

    /** The hit sound while mining. */
    @ModifyVariable(
            method = "continueDestroyBlock",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;getSoundType()Lnet/minecraft/world/level/block/SoundType;"
            ),
            ordinal = 0
    )
    private class_2498 assortedlib_injectGetBlockStateSoundType(final class_2498 current, final class_2338 pos, final class_2350 direction) {
        final class_2680 blockState = this.minecraft.field_1687.method_8320(pos);
        if (blockState.method_26204() instanceof IBlockSoundType extraProperties) {
            return extraProperties.getSoundType(blockState, this.minecraft.field_1687, pos, this.minecraft.field_1724);
        }
        return current;
    }

    @Inject(method = "interact",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/ClientPacketListener;send(Lnet/minecraft/network/protocol/Packet;)V",
                    shift = At.Shift.AFTER),
            cancellable = true)
    private void assortedlib_entityInteract(class_1657 player, class_1297 entity, class_1268 interactionHand, CallbackInfoReturnable<class_1269> cir) {
        final EntityInteractEvent event = new EntityInteractEvent(player, interactionHand, entity);
        Services.EVENTS.handleEvents(event);

        if (event.getInteractionResult() == class_1269.field_5812) {
            cir.setReturnValue(class_1269.field_5812);
        }
    }

    /**
     * The client half of {@link IBlockOnPlayerBreak}: refusing here is what keeps the client from
     * playing a break the server is going to refuse anyway.
     */
    @Inject(method = "destroyBlock", at = @At("HEAD"), cancellable = true)
    private void assortedlib_canPlayerBreak(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        final class_1937 level = this.minecraft.field_1687;
        final class_2680 state = level.method_8320(pos);
        if (state.method_26204() instanceof IBlockOnPlayerBreak onPlayerBreak && !onPlayerBreak.canPlayerBreak(state, level, pos, this.minecraft.field_1724)) {
            cir.setReturnValue(false);
        }
    }
}
