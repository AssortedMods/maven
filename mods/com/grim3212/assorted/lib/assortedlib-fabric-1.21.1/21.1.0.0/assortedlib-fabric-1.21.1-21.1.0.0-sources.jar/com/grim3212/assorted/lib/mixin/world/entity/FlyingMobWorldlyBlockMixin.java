package com.grim3212.assorted.lib.mixin.world.entity;

import com.grim3212.assorted.lib.core.block.IBlockExtraProperties;
import com.grim3212.assorted.lib.mixin.entity.EntityAccessor;
import net.minecraft.class_1299;
import net.minecraft.class_1307;
import net.minecraft.class_1308;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Feeds the position dependent {@link IBlockExtraProperties} friction into {@link class_1307#method_6091},
 * which reads {@code Block#getFriction()} twice for the block below that affects movement - once for
 * the acceleration, once for the drag - and does not go through {@code LivingEntity#travel}.
 */
@Mixin(class_1307.class)
public abstract class FlyingMobWorldlyBlockMixin extends class_1308 {

    protected FlyingMobWorldlyBlockMixin(final class_1299<? extends class_1308> entityType, final class_1937 level) {
        super(entityType, level);
    }

    @Redirect(
            method = "travel",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/Block;getFriction()F")
    )
    private float assortedlib_rewriteFrictionValueForWorldlyBlocks(final class_2248 block) {
        if (!((Object) this instanceof EntityAccessor entityAccessor)) {
            return block.method_9499();
        }

        final class_2338 pos = this.method_23314();
        final class_2680 blockState = entityAccessor.getLevel().method_8320(pos);
        if (blockState.method_26204() instanceof IBlockExtraProperties extraProperties) {
            return extraProperties.getFriction(blockState, entityAccessor.getLevel(), pos, this);
        }

        return block.method_9499();
    }
}
