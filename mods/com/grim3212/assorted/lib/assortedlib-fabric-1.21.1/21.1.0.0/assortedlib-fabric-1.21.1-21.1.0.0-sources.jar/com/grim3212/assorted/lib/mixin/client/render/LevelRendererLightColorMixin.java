package com.grim3212.assorted.lib.mixin.client.render;

import com.grim3212.assorted.lib.core.block.IBlockLightEmission;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Feeds the position dependent {@link IBlockLightEmission} value into the packed light coordinates
 * a block is drawn with. {@link class_761#method_23793(class_1920, class_2680, class_2338)}
 * is where every call site packs block light.
 */
@Mixin(class_761.class)
public abstract class LevelRendererLightColorMixin {

    @Redirect(
            method = "getLightColor(Lnet/minecraft/world/level/BlockAndTintGetter;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;)I",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;getLightEmission()I"
            )
    )
    private static int assortedlib_injectGetBlockStateLightEmission(final class_2680 instance, final class_1920 level, final class_2680 state, final class_2338 pos) {
        if (instance.method_26204() instanceof IBlockLightEmission extraProperties) {
            return extraProperties.getLightEmission(instance, level, pos);
        }

        return instance.method_26213();
    }
}
