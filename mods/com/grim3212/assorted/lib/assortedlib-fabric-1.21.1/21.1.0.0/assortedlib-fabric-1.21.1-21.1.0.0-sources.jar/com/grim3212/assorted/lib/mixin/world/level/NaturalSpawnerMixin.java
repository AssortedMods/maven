package com.grim3212.assorted.lib.mixin.world.level;

import com.grim3212.assorted.lib.worldgen.StructureSpawns;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1311;
import net.minecraft.class_1948;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2794;
import net.minecraft.class_3218;
import net.minecraft.class_5138;
import net.minecraft.class_5483;
import net.minecraft.class_6012;
import net.minecraft.class_6880;

/**
 * Appends {@link StructureSpawns} to what may spawn at a position. NeoForge fires
 * {@code LevelEvent.PotentialSpawns} from this same method; Fabric's API only reaches biomes, so the
 * result is extended here instead. Nothing vanilla allows is removed or reweighted.
 */
@Mixin(class_1948.class)
public abstract class NaturalSpawnerMixin {

    @Inject(method = "mobsAt", at = @At("RETURN"), cancellable = true)
    private static void assortedlib_addStructureSpawns(class_3218 level, class_5138 structureManager, class_2794 generator, class_1311 category, class_2338 pos, @Nullable class_6880<class_1959> biome,
                                                       CallbackInfoReturnable<class_6012<class_5483.class_1964>> cir) {
        List<class_5483.class_1964> added = StructureSpawns.at(structureManager, category, pos);
        if (!added.isEmpty()) {
            List<class_5483.class_1964> spawns = new ArrayList<>(cir.getReturnValue().method_34994());
            spawns.addAll(added);
            cir.setReturnValue(class_6012.method_34988(spawns));
        }
    }
}
