package com.grim3212.assorted.lib.client.model.loader;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.grim3212.assorted.lib.client.model.loaders.IModelSpecification;
import com.grim3212.assorted.lib.client.model.loaders.IModelSpecificationLoader;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2960;
import net.minecraft.class_3518;

/**
 * The model loaders registered through {@code IClientHelper#registerModelLoader}, by the id a model
 * json names in its {@code "loader"} key - the key NeoForge reads, so one json serves both loaders.
 * Fabric API has no custom model loaders in 1.21.1, so {@code BlockModelDeserializerMixin} asks here
 * as vanilla parses each model json.
 */
public final class FabricModelLoaders {

    private static final Map<class_2960, IModelSpecificationLoader<?>> LOADERS = new ConcurrentHashMap<>();

    private FabricModelLoaders() {
    }

    public static void register(final class_2960 name, final IModelSpecificationLoader<?> loader) {
        if (LOADERS.putIfAbsent(name, loader) != null) {
            throw new IllegalStateException("Model loader " + name + " is already registered");
        }
    }

    /** The specification the json's {@code loader} reads, or null when it names none of ours. */
    @Nullable
    public static IModelSpecification<?> read(final JsonDeserializationContext context, final JsonObject json) {
        if (!json.has("loader")) {
            return null;
        }

        final class_2960 name = class_2960.method_12829(class_3518.method_15265(json, "loader"));
        final IModelSpecificationLoader<?> loader = name == null ? null : LOADERS.get(name);
        if (loader == null) {
            return null;
        }

        final IModelSpecification<?> specification = loader.read(context, json);
        if (specification == null) {
            throw new JsonParseException("Model loader " + name + " read nothing");
        }
        return specification;
    }
}
