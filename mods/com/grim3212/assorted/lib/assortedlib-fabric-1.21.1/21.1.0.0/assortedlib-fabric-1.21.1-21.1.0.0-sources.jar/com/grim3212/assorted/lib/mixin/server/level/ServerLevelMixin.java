package com.grim3212.assorted.lib.mixin.server.level;

import com.grim3212.assorted.lib.worldgen.CustomSpawners;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_3218;
import net.minecraft.class_5304;

/** Fabric API has no ModifyCustomSpawnersEvent, so {@link CustomSpawners} are appended to the field here; vanilla's stay first. */
@Mixin(class_3218.class)
public abstract class ServerLevelMixin {

    @Shadow
    @Final
    @Mutable
    private List<class_5304> customSpawners;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void assortedlib_addCustomSpawners(CallbackInfo ci) {
        List<class_5304> added = CustomSpawners.createFor((class_3218) (Object) this);
        if (!added.isEmpty()) {
            List<class_5304> all = new ArrayList<>(this.customSpawners);
            all.addAll(added);
            this.customSpawners = List.copyOf(all);
        }
    }
}
