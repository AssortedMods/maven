package com.grim3212.assorted.lib.mixin.client.model;

import com.grim3212.assorted.lib.client.model.loader.FabricModelBakingContextDelegate;
import com.grim3212.assorted.lib.client.model.loader.ISpecificationBlockModel;
import com.grim3212.assorted.lib.client.model.loaders.IModelSpecification;
import com.grim3212.assorted.lib.platform.ClientServices;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Collection;
import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_806;

/**
 * Bakes a {@link class_793} whose json, or a parent's, named one of our loaders through its
 * {@link IModelSpecification}, the way NeoForge bakes custom geometry: an item model whose parent is
 * a loader model bakes through the parent's specification, with its own textures and transforms.
 * The models a specification reaches through the baker are added to the model's dependencies, so the
 * bakery loads them, and their parents are resolved with the model's own; vanilla only resolves the
 * top level models' parents.
 */
@Mixin(class_793.class)
public abstract class BlockModelSpecificationMixin implements ISpecificationBlockModel {

    @Shadow
    @Nullable
    protected class_793 parent;

    @Unique
    @Nullable
    private IModelSpecification<?> assortedlib$specification;

    @Shadow
    protected abstract class_806 getItemOverrides(class_7775 baker, class_793 model);

    @Override
    public @Nullable IModelSpecification<?> assortedlib$getSpecification() {
        return this.assortedlib$specification;
    }

    @Override
    public void assortedlib$setSpecification(@Nullable final IModelSpecification<?> specification) {
        this.assortedlib$specification = specification;
    }

    @Unique
    @Nullable
    private static class_793 assortedlib$parentOf(final class_793 model) {
        return ((BlockModelSpecificationMixin) (Object) model).parent;
    }

    /** The nearest specification up the parent chain, this model's own first. */
    @Unique
    @Nullable
    private IModelSpecification<?> assortedlib$inheritedSpecification() {
        for (class_793 model = (class_793) (Object) this; model != null; model = assortedlib$parentOf(model)) {
            final IModelSpecification<?> specification = ((ISpecificationBlockModel) model).assortedlib$getSpecification();
            if (specification != null) {
                return specification;
            }
        }
        return null;
    }

    @Inject(method = "getDependencies", at = @At("RETURN"))
    private void assortedlib_addSpecificationDependencies(final CallbackInfoReturnable<Collection<class_2960>> cir) {
        if (this.assortedlib$specification != null) {
            cir.getReturnValue().addAll(this.assortedlib$specification.getDependencies());
        }
    }

    @Inject(method = "resolveParents", at = @At("TAIL"))
    private void assortedlib_resolveSpecificationDependencies(final Function<class_2960, class_1100> resolver, final CallbackInfo ci) {
        for (class_793 model = (class_793) (Object) this; model != null; model = assortedlib$parentOf(model)) {
            final IModelSpecification<?> specification = ((ISpecificationBlockModel) model).assortedlib$getSpecification();
            if (specification == null) {
                continue;
            }

            for (final class_2960 dependency : specification.getDependencies()) {
                final class_1100 unbaked = resolver.apply(dependency);
                if (unbaked != null && unbaked != (Object) this) {
                    unbaked.method_45785(resolver);
                }
            }
        }
    }

    @Inject(
            method = "bake(Lnet/minecraft/client/resources/model/ModelBaker;Ljava/util/function/Function;Lnet/minecraft/client/resources/model/ModelState;)Lnet/minecraft/client/resources/model/BakedModel;",
            at = @At("HEAD"),
            cancellable = true
    )
    private void assortedlib_bakeSpecification(final class_7775 baker, final Function<class_4730, class_1058> spriteGetter, final class_3665 modelState, final CallbackInfoReturnable<class_1087> cir) {
        final IModelSpecification<?> specification = this.assortedlib$inheritedSpecification();
        if (specification == null) {
            return;
        }

        final class_793 self = (class_793) (Object) this;
        final FabricModelBakingContextDelegate context = new FabricModelBakingContextDelegate(self, baker);
        final class_1087 baked = specification.bake(context, baker, spriteGetter, modelState, this.getItemOverrides(baker, self));
        cir.setReturnValue(ClientServices.MODELS.adaptToPlatform(baked));
    }
}
