package com.grim3212.assorted.lib.mixin.world.level;

import com.grim3212.assorted.lib.core.block.IBlockOnPlayerBreak;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3225.class)
public abstract class ServerPlayerGameModeMixin {

    @Shadow
    protected class_3218 level;
    @Shadow
    protected class_3222 player;

    /**
     * The server half of {@link IBlockOnPlayerBreak}, at the head of {@code destroyBlock} where
     * NeoForge fires its own {@code BreakBlockEvent}. Answering false is what the method already
     * does for a block the player may not break.
     */
    @Inject(method = "destroyBlock", at = @At("HEAD"), cancellable = true)
    private void assortedlib_canPlayerBreak(class_2338 pos, CallbackInfoReturnable<Boolean> info) {
        final class_2680 state = this.level.method_8320(pos);
        if (state.method_26204() instanceof IBlockOnPlayerBreak onPlayerBreak && !onPlayerBreak.canPlayerBreak(state, this.level, pos, this.player)) {
            info.setReturnValue(false);
        }
    }
}
