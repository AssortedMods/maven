package com.grim3212.assorted.lib.mixin.world.entity.vehicle;

import com.grim3212.assorted.lib.core.block.IBlockExtraProperties;
import com.grim3212.assorted.lib.mixin.entity.EntityAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1690;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Feeds the position dependent {@link IBlockExtraProperties} friction into
 * {@code getGroundFriction} on {@link class_1690}, which covers boats, chest boats and rafts.
 */
@Mixin(value = class_1690.class, priority = Integer.MIN_VALUE)
public abstract class BoatWorldlyBlockMixin extends class_1297 {

    @Unique
    private class_2680 workingState;
    @Unique
    private class_2338 workingPos;

    public BoatWorldlyBlockMixin(final class_1299<?> entityType, final class_1937 level) {
        super(entityType, level);
    }

    @ModifyArg(
            method = "getGroundFriction",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/Level;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;"
            ),
            index = 0
    )
    private class_2338 assortedlib_injectGetFrictionAdaptorForPosition(final class_2338 pos) {
        this.workingPos = pos;
        return pos;
    }

    @ModifyVariable(
            method = "getGroundFriction",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/level/Level;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;"
            ),
            ordinal = 0
    )
    private class_2680 assortedlib_injectGetFrictionAdaptorForState(final class_2680 current) {
        this.workingState = current;
        return current;
    }

    /** The friction is summed straight off the call, so the call itself is what gets replaced. */
    @Redirect(
            method = "getGroundFriction",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/Block;getFriction()F"
            )
    )
    private float assortedlib_injectGetFrictionAdaptorForBlock(final class_2248 block) {
        if ((Object) this instanceof EntityAccessor entityAccessor && block instanceof IBlockExtraProperties extraProperties) {
            return extraProperties.getFriction(this.workingState, entityAccessor.getLevel(), this.workingPos, this);
        }

        return block.method_9499();
    }
}
