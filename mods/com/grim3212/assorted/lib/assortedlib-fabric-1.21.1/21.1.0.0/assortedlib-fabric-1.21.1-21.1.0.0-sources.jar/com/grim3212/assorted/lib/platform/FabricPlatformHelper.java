package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.conditions.PartToggles;
import org.jetbrains.annotations.Nullable;
import com.grim3212.assorted.lib.core.item.IStackTooltipProvider;
import net.fabricmc.fabric.api.registry.CompostingChanceRegistry;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import com.grim3212.assorted.lib.core.inventory.IMenuDataProvider;
import com.grim3212.assorted.lib.core.inventory.MenuData;
import com.grim3212.assorted.lib.dist.Dist;
import com.grim3212.assorted.lib.platform.services.IPlatformHelper;
import com.grim3212.assorted.lib.registry.ILoaderRegistry;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.item.v1.DefaultItemComponentEvents;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1266;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1317;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3264;
import net.minecraft.class_3302;
import net.minecraft.class_3730;
import net.minecraft.class_3908;
import net.minecraft.class_3917;
import net.minecraft.class_3956;
import net.minecraft.class_5132;
import net.minecraft.class_5321;
import net.minecraft.class_5425;
import net.minecraft.class_7701;
import net.minecraft.class_7923;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9168;
import net.minecraft.class_9323;
import net.minecraft.class_9331;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class FabricPlatformHelper implements IPlatformHelper {

    @Override
    public String getPlatformName() {
        return "Fabric";
    }


    @Override
    public void openMenu(class_3222 player, class_3908 provider) {
        if (provider instanceof IMenuDataProvider<?> withData) {
            player.method_17355(new DataMenuProvider<>(withData));
        } else {
            player.method_17355(provider);
        }
    }

    @Override
    public boolean isModLoaded(String modId) {
        return FabricLoader.getInstance().isModLoaded(modId);
    }

    @Override
    public boolean isFakePlayer(class_1657 player) {
        return false;
    }

    @Override
    public double getPlayerReachDistance(class_1657 player) {
        return player.method_7337() ? 5.0F : 4.5F;
    }

    @Override
    public Dist getCurrentDistribution() {
        return switch (FabricLoader.getInstance().getEnvironmentType()) {
            case CLIENT -> Dist.CLIENT;
            case SERVER -> Dist.DEDICATED_SERVER;
        };
    }

    @Override
    public boolean isPhysicalClient() {
        return this.getCurrentDistribution() == Dist.CLIENT;
    }

    @Override
    public boolean isProduction() {
        return !FabricLoader.getInstance().isDevelopmentEnvironment();
    }

    @Override
    public <T> ILoaderRegistry<T> getRegistry(class_5321<? extends class_2378<T>> key) {
        return FabricRegistryWrapper.getRegistry(key);
    }

    @Override
    public void modifyCreativeTab(class_5321<class_1761> key, Supplier<List<class_1799>> displayStacks) {
        ItemGroupEvents.modifyEntriesEvent(key).register(entries -> {
            entries.method_45423(PartToggles.visible(displayStacks.get()));
        });
    }

    @Override
    public void registerCreativeTab(class_2960 id, Supplier<class_1761> tab) {
        class_2378.method_10230(class_7923.field_44687, id, tab.get());
    }

    // Fabric registries stay open through every mod's initializer, so this can register at once.
    @Override
    public void registerDataComponentType(class_2960 id, Supplier<? extends class_9331<?>> type) {
        class_2378.method_10230(class_7923.field_49658, id, type.get());
    }

    @Override
    public void modifyDefaultComponents(Supplier<? extends class_1935> item, Consumer<class_9323.class_9324> components) {
        DefaultItemComponentEvents.MODIFY.register(context -> context.modify(item.get().method_8389(), components));
    }

    @Override
    public <T extends IStackTooltipProvider> void showComponentTooltip(Supplier<class_9331<T>> type) {
        // Fabric's tooltip event is raised by a client mixin only, so there is nothing to hook on a dedicated server.
        if (this.isPhysicalClient()) {
            FabricComponentTooltips.show(type.get());
        }
    }

    @Override
    public <T extends class_1309> void registerEntityAttributes(Supplier<class_1299<T>> type, Supplier<class_5132.class_5133> attributes) {
        FabricDefaultAttributeRegistry.register(type.get(), attributes.get());
    }

    @Override
    public void registerFlammable(Supplier<? extends class_2248> block, int igniteOdds, int burnOdds) {
        FlammableBlockRegistry.getDefaultInstance().add(block.get(), burnOdds, igniteOdds);
    }

    @Override
    public @Nullable class_1315 finalizeSpawn(class_1308 mob, class_5425 level, class_1266 difficulty, class_3730 reason, @Nullable class_1315 groupData) {
        return mob.method_5943(level, difficulty, reason, groupData);
    }

    @Override
    public <T extends class_1308> void registerSpawnPlacement(Supplier<class_1299<T>> type, class_9168 placement, class_2902.class_2903 heightmap, class_1317.class_4306<T> predicate) {
        class_1317.method_20637(type.get(), placement, heightmap, predicate);
    }

    @Override
    public void addReloadListener(class_2960 identifier, class_3302 reloadListener) {
        ResourceManagerHelper.get(class_3264.field_14190).registerReloadListener(new FabricIdentifiedReloadListener(identifier, reloadListener));
    }

    @Override
    public void registerFuel(Supplier<? extends class_1935> item, int burnTime) {
        FuelRegistry.INSTANCE.add(item.get(), burnTime);
    }

    @Override
    public void registerCompostable(Supplier<? extends class_1935> item, float chance) {
        CompostingChanceRegistry.INSTANCE.add(item.get(), chance);
    }

    @Override
    public int getFuelTime(class_1799 stack, @Nullable class_3956<?> recipeType) {
        if (stack.method_7960()) {
            return 0;
        }
        Integer time = FuelRegistry.INSTANCE.get(stack.method_7909());
        return time == null ? 0 : time;
    }

    @Override
    public <T extends class_2586> class_2591<T> createBlockEntityType(BiFunction<class_2338, class_2680, T> builder, class_2248... blocks) {
        // The data fixer type is null for a modded block entity, as vanilla's own lookup answers for any
        // type it has no schema for.
        return class_2591.class_2592.<T>method_20528(builder::apply, blocks).method_11034(null);
    }

    @Override
    public <T extends class_1703, D> class_3917<T> createMenuType(MenuFactory<T, D> factory, class_9139<? super class_9129, D> codec) {
        class_3917<T> type = new ExtendedScreenHandlerType<>(factory::create, codec);
        MenuData.register(type, factory, codec);
        return type;
    }

    @Override
    public <T extends class_1703> class_3917<T> createMenuType(SimpleMenuFactory<T> factory) {
        return new class_3917<>(factory::create, class_7701.field_40182);
    }

    /** Fabric writes the data with the codec its {@link ExtendedScreenHandlerType} carries. */
    private record DataMenuProvider<D>(IMenuDataProvider<D> provider) implements ExtendedScreenHandlerFactory<D> {
        @Override
        public D getScreenOpeningData(class_3222 player) {
            return provider.getMenuData(player);
        }

        @Override
        public class_2561 method_5476() {
            return provider.method_5476();
        }

        @Override
        public class_1703 createMenu(int windowId, class_1661 inventory, class_1657 player) {
            return provider.createMenu(windowId, inventory, player);
        }
    }
}
