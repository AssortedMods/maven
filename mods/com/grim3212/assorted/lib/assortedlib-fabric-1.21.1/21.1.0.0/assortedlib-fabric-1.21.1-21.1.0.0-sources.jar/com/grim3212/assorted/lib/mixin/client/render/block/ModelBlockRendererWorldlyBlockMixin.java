package com.grim3212.assorted.lib.mixin.client.render.block;

import com.grim3212.assorted.lib.core.block.IBlockLightEmission;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import net.minecraft.class_778;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Gives a block whose light emission is position dependent ambient occlusion where it emits
 * nothing. {@code tesselateBlock} picks AO on {@code blockState.getLightEmission() == 0}, so
 * redirecting that lookup is enough and keeps the rest of vanilla's decision.
 */
@Mixin(class_778.class)
public abstract class ModelBlockRendererWorldlyBlockMixin {

    @Redirect(
            method = "tesselateBlock",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;getLightEmission()I"
            )
    )
    private int assortedlib_handleWorldlyBlocksWhichDoNotEmitDefaultLightForAO(final class_2680 instance, final class_1920 level, final class_1087 model, final class_2680 blockState, final class_2338 pos, final class_4587 poseStack, final class_4588 consumer, final boolean checkSides, final class_5819 random, final long seed, final int packedOverlay) {
        if (instance.method_26204() instanceof IBlockLightEmission extraProperties) {
            return extraProperties.getLightEmission(instance, level, pos);
        }

        return instance.method_26213();
    }
}
