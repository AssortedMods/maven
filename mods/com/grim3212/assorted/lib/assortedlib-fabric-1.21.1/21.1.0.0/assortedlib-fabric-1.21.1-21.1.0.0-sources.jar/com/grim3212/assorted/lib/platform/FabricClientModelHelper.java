package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.client.model.data.*;
import com.grim3212.assorted.lib.client.model.loader.FabricBakedModelDelegate;
import com.grim3212.assorted.lib.platform.services.IClientModelHelper;
import org.jetbrains.annotations.NotNull;

import com.grim3212.assorted.lib.client.model.baked.IDataAwareBakedModel;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_4696;
import net.minecraft.class_5819;

public class FabricClientModelHelper implements IClientModelHelper {

    @Override
    public void requestModelDataRefresh(class_2586 blockEntity) {
        // NO-OP
    }

    private static final IBlockModelData EMPTY = new ModelDataBuilder().build();

    @Override
    public IBlockModelData empty() {
        return EMPTY;
    }

    @Override
    public @NotNull IModelDataBuilder createNewModelDataBuilder() {
        return new ModelDataBuilder();
    }

    @Override
    public @NotNull <T> IModelDataKey<T> createNewModelDataKey() {
        return new ModelDataKey<>();
    }

    @Override
    public class_1087 adaptToPlatform(class_1087 model) {
        // Only a data aware model needs the delegate, which feeds it the model data of the position
        // it is drawn at; any other model already draws through Fabric's vanilla adapter.
        if (model instanceof FabricBakedModelDelegate || !(model instanceof IDataAwareBakedModel)) {
            return model;
        }

        return new FabricBakedModelDelegate(model);
    }

    /** Fabric has no per-model layers: a block draws in the chunk layer registered for it. */
    @Override
    public @NotNull Collection<class_1921> getRenderTypesFor(class_1087 model, class_2680 state, class_5819 rand, IBlockModelData data) {
        return List.of(class_4696.method_23679(state));
    }

    @Override
    public @NotNull List<class_1921> getRenderTypesFor(class_1087 model, class_1799 stack, boolean fabulous) {
        return List.of(class_4696.method_23678(stack, fabulous));
    }
}
