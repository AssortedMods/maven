package com.grim3212.assorted.lib.mixin.client.render;

import com.grim3212.assorted.lib.core.block.IBlockSoundType;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_761;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Plays the {@link IBlockSoundType} sound instead of the baked in one for the block break level
 * event. A redirect, so the event data (the block state id) is at hand in a single injection.
 */
@Mixin(class_761.class)
public abstract class LevelRendererWorldlyBlockMixin {

    @Shadow
    @Nullable
    private class_638 level;

    @Redirect(
            method = "levelEvent",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;getSoundType()Lnet/minecraft/world/level/block/SoundType;"
            )
    )
    public class_2498 assortedlib_redirectGetBlockStateSoundType(final class_2680 blockState, final int type, final class_2338 pos, final int data) {
        if (this.level != null && blockState.method_26204() instanceof IBlockSoundType extraProperties) {
            return extraProperties.getSoundType(blockState, this.level, pos, class_310.method_1551().method_1560());
        }

        return blockState.method_26231();
    }
}
