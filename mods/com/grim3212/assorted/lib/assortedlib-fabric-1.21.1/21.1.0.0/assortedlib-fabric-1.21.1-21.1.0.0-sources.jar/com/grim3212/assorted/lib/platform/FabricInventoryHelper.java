package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.core.inventory.IInventoryBlockEntity;
import com.grim3212.assorted.lib.core.inventory.IInventoryItem;
import com.grim3212.assorted.lib.core.inventory.IItemStorageHandler;
import com.grim3212.assorted.lib.core.inventory.IPlatformInventoryStorageHandler;
import com.grim3212.assorted.lib.inventory.FabricPlatformInventoryStorageHandlerSided;
import com.grim3212.assorted.lib.inventory.FabricPlatformInventoryStorageHandlerUnsided;
import com.grim3212.assorted.lib.inventory.FabricWrappedItemHandler;
import com.grim3212.assorted.lib.platform.services.IInventoryHelper;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.SlottedStorage;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.function.Function;

public class FabricInventoryHelper implements IInventoryHelper {
    @Override
    public boolean canItemStacksStack(@NotNull class_1799 a, @NotNull class_1799 b) {
        // Stack NBT became data components, and vanilla already compares the whole component map.
        return !a.method_7960() && class_1799.method_31577(a, b);
    }

    @Override
    public class_1799 copyStackWithSize(@NotNull class_1799 itemStack, int size) {
        if (size == 0)
            return class_1799.field_8037;
        class_1799 copy = itemStack.method_7972();
        copy.method_7939(size);
        return copy;
    }

    @Override
    public Optional<IItemStorageHandler> getItemStorageHandler(class_1799 stack) {
        if (stack.method_7960())
            return Optional.empty();

        if (stack.method_7909() instanceof IInventoryItem itemStackStorage) {
            IPlatformInventoryStorageHandler storageHandler = itemStackStorage.getStorageHandler(stack);
            if (storageHandler != null) {
                return Optional.of(storageHandler.getItemStorageHandler(null));
            }
        }

        return Optional.empty();
    }

    @Override
    public Optional<IItemStorageHandler> getItemStorageHandler(class_2586 blockEntity, @Nullable class_2350 direction) {
        if (blockEntity == null || blockEntity.method_11015())
            return Optional.empty();

        if (blockEntity instanceof IInventoryBlockEntity inventoryBlockEntity) {
            IPlatformInventoryStorageHandler storageHandler = inventoryBlockEntity.getStorageHandler();
            if (storageHandler != null) {
                return Optional.of(storageHandler.getItemStorageHandler(direction));
            }
        }

        // ItemStorage.SIDED already falls back to WorldlyContainerHolder blocks and to block entities
        // that are plain Containers, so those need no special case of their own. A storage that is not
        // slotted has nothing to map the slot indexed IItemStorageHandler onto, so it is left alone.
        if (ItemStorage.SIDED.find(blockEntity.method_10997(), blockEntity.method_11016(), direction) instanceof SlottedStorage<ItemVariant> slottedStorage) {
            return Optional.of(new FabricWrappedItemHandler(blockEntity, slottedStorage));
        }

        return Optional.empty();
    }

    @Override
    public IPlatformInventoryStorageHandler createStorageInventoryHandler(IItemStorageHandler handler) {
        return new FabricPlatformInventoryStorageHandlerUnsided(handler);
    }

    @Override
    public IPlatformInventoryStorageHandler createSidedStorageInventoryHandler(Function<class_2350, IItemStorageHandler> handler) {
        return new FabricPlatformInventoryStorageHandlerSided(handler);
    }
}
