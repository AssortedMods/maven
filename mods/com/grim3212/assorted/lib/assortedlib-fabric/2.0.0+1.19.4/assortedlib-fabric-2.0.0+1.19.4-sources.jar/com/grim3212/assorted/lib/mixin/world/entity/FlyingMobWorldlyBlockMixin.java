package com.grim3212.assorted.lib.mixin.world.entity;

import com.grim3212.assorted.lib.core.block.IBlockExtraProperties;
import net.minecraft.class_1299;
import net.minecraft.class_1307;
import net.minecraft.class_1308;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1307.class)
public abstract class FlyingMobWorldlyBlockMixin extends class_1308 {
    protected FlyingMobWorldlyBlockMixin(final class_1299<? extends class_1308> entityType, final class_1937 level) {
        super(entityType, level);
    }

    @ModifyVariable(
            method = "travel",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/level/block/Block;getFriction()F"
            ),
            ordinal = 0
    )
    private float assortedlib_injectGetFrictionAdaptorForGCalculation(final float current) {
        return assortedlib_handleInjectionPoint(current);
    }

    private float assortedlib_handleInjectionPoint(final float current) {
        final class_2338 pPos = new class_2338(this.method_31477(), this.method_31478(), this.method_31479()).method_10074();
        final class_2680 blockState = this.field_6002.method_8320(pPos);

        if (blockState.method_26204() instanceof IBlockExtraProperties extraProperties) {
            return extraProperties.getFriction(blockState, this.field_6002, pPos, this) * 0.91f;
        }
        return current;
    }
}
