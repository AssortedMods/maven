package com.grim3212.assorted.lib.mixin.world.entity.vehicle;

import com.grim3212.assorted.lib.core.block.IBlockExtraProperties;
import com.grim3212.assorted.lib.mixin.entity.EntityAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1690;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(value = class_1690.class, priority = Integer.MIN_VALUE)
public abstract class BoatWorldlyBlockMixin extends class_1297 {

    @Unique
    private class_2680 workingState;
    @Unique
    private class_2338 workingPos;

    public BoatWorldlyBlockMixin(final class_1299<?> entityType, final class_1937 level) {
        super(entityType, level);
    }


    @Inject(
            method = "getGroundFriction",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/core/BlockPos$MutableBlockPos;set(III)Lnet/minecraft/core/BlockPos$MutableBlockPos;"
            ),
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    private void assortedlib_injectGetFrictionAdaptorForPosition(final CallbackInfoReturnable<Float> cir, final class_238 aABB, final class_238 aABB2, final int i, final int j, final int k, final int l, final int m, final int n, final class_265 voxelShape, final float f, final int o, final class_2338.class_2339 mutableBlockPos) {
        this.workingPos = mutableBlockPos;
    }

    @SuppressWarnings("InvalidInjectorMethodSignature")
    @ModifyVariable(
            method = "getGroundFriction",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/level/Level;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;"
            ),
            ordinal = 0
    )
    private class_2680 assortedlib_injectGetFrictionAdaptorForState(final class_2680 current) {
        this.workingState = current;
        return current;
    }

    @ModifyVariable(
            method = "getGroundFriction",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/level/block/Block;getFriction()F"
            ),
            ordinal = 0
    )
    private float assortedlib_injectGetFrictionAdaptorForState(final float current) {
        if (!(this instanceof EntityAccessor entityAccessor))
            return current;

        if (this.workingState.method_26204() instanceof IBlockExtraProperties extraProperties) {
            return extraProperties.getFriction(this.workingState, entityAccessor.getLevel(), this.workingPos, this);
        }

        return current;
    }
}
