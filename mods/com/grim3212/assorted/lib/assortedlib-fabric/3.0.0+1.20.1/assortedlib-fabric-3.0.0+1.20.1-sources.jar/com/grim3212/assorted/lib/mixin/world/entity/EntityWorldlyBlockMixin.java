package com.grim3212.assorted.lib.mixin.world.entity;

import com.grim3212.assorted.lib.core.block.IBlockSoundType;
import com.grim3212.assorted.lib.core.block.effects.IBlockRunningEffects;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3481;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_1297.class)
public abstract class EntityWorldlyBlockMixin {

    @Shadow
    public class_1937 level;

    @Shadow
    public abstract void playSound(final class_3414 sound, final float volume, final float pitch);

    private class_1297 getThis() {
        return (class_1297) (Object) this;
    }

    @SuppressWarnings("InvalidInjectorMethodSignature")
    @Inject(
            method = "playStepSound",
            at = @At(
                    value = "HEAD"
            ),
            cancellable = true
    )
    public void assortedlib_redirectGetOffsetBlockStateSoundType(class_2338 pos, class_2680 state, CallbackInfo ci) {
        if (!state.method_51176()) {
            class_2680 blockState = this.level.method_8320(pos.method_10084());
            blockState = blockState.method_26164(class_3481.field_28040) ? blockState : state;

            if (blockState.method_26204() instanceof IBlockSoundType extraProperties) {
                class_2498 soundType = extraProperties.getSoundType(blockState, this.level, pos, this.getThis());
                this.playSound(soundType.method_10594(), soundType.method_10597() * 0.15F, soundType.method_10599());
                ci.cancel();
            }
        }
    }

    @Inject(
            method = "spawnSprintParticle",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/Level;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;"
            ),
            locals = LocalCapture.CAPTURE_FAILHARD,
            cancellable = true
    )
    public void assortedlib_spawnSprintParticle(CallbackInfo ci, class_2338 blockPos) {
        class_2680 state = this.level.method_8320(blockPos);
        if (state.method_26204() instanceof IBlockRunningEffects extraProperties && extraProperties.addRunningEffects(state, level, blockPos, (class_1297) (Object) this)) {
            ci.cancel();
        }
    }
}
