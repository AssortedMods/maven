package com.grim3212.assorted.lib.mixin.world.entity.item;

import com.grim3212.assorted.lib.core.block.IBlockExtraProperties;
import com.grim3212.assorted.lib.mixin.entity.EntityAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1542.class)
public abstract class ItemEntityWorldlyBlockMixin extends class_1297 {
    public ItemEntityWorldlyBlockMixin(final class_1299<?> entityType, final class_1937 level) {
        super(entityType, level);
    }

    @ModifyVariable(
            method = "tick",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/level/block/Block;getFriction()F"
            ),
            ordinal = 0
    )
    private float assortedlib_injectGetFrictionAdaptor(final float current) {
        if (!(this instanceof EntityAccessor entityAccessor))
            return current;

        final class_2338 pPos = new class_2338(this.method_31477(), this.method_31478(), this.method_31479()).method_10074();
        final class_2680 blockState = entityAccessor.getLevel().method_8320(pPos);

        if (blockState.method_26204() instanceof IBlockExtraProperties extraProperties) {
            return extraProperties.getFriction(blockState, entityAccessor.getLevel(), pPos, this) * 0.98f;
        }
        return current;
    }
}
