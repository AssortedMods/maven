package com.grim3212.assorted.lib.testing;

import com.grim3212.assorted.lib.LibConstants;
import com.grim3212.assorted.lib.registry.IRegistryObject;
import com.grim3212.assorted.lib.registry.RegistryProvider;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2766;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7924;

public class FabricTests {

    public static final RegistryProvider<class_2248> BLOCKS = RegistryProvider.create(class_7924.field_41254, LibConstants.MOD_ID);
    public static final RegistryProvider<class_1792> ITEMS = RegistryProvider.create(class_7924.field_41197, LibConstants.MOD_ID);

    public static final IRegistryObject<BlockBreakCancelTest> blockBreakTest = register("test", () -> new BlockBreakCancelTest(class_4970.class_2251.method_9637().method_31710(class_3620.field_16023).method_51368(class_2766.field_12653)));

    private static <T extends class_2248> IRegistryObject<T> register(String name, Supplier<? extends T> sup) {
        return register(name, sup, block -> item(block));
    }

    private static <T extends class_2248> IRegistryObject<T> register(String name, Supplier<? extends T> sup, Function<IRegistryObject<T>, Supplier<? extends class_1792>> itemCreator) {
        IRegistryObject<T> ret = registerNoItem(name, sup);
        ITEMS.register(name, itemCreator.apply(ret));
        return ret;
    }

    private static <T extends class_2248> IRegistryObject<T> registerNoItem(String name, Supplier<? extends T> sup) {
        return BLOCKS.register(name, sup);
    }

    private static Supplier<class_1747> item(final IRegistryObject<? extends class_2248> block) {
        return () -> new class_1747(block.get(), new class_1792.class_1793());
    }

    public static void init() {
    }
}
