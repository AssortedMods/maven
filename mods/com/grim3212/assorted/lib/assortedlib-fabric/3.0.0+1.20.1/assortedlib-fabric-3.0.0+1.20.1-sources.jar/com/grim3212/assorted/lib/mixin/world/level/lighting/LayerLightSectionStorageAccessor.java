package com.grim3212.assorted.lib.mixin.world.level.lighting;

import net.minecraft.class_3556;
import net.minecraft.class_3560;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_3560.class)
public interface LayerLightSectionStorageAccessor<M extends class_3556<M>> {

    @Invoker
    boolean callLightOnInSection(long sectionPos);
}
