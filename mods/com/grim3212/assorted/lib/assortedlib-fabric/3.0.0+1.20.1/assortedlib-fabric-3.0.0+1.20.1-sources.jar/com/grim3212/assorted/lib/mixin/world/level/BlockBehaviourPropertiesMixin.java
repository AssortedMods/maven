package com.grim3212.assorted.lib.mixin.world.level;

import com.grim3212.assorted.lib.core.block.IBlockLightEmission;
import net.minecraft.class_1299;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4970.class_2251.class)
public class BlockBehaviourPropertiesMixin {


    @Inject(method = "method_26239", remap = false, at = @At("HEAD"), cancellable = true)
    private static void assortedlib_onCallDefaultIsValidSpawnCallback(final class_2680 blockState, final class_1922 blockGetter, final class_2338 position, final class_1299<?> entityType, CallbackInfoReturnable<Boolean> cir) {
        if (!(blockState.method_26204() instanceof IBlockLightEmission lightEmission))
            return;

        cir.setReturnValue(blockState.method_26206(blockGetter, position, class_2350.field_11036) && lightEmission.getLightEmission(blockState, blockGetter, position) < 14);
    }
}
