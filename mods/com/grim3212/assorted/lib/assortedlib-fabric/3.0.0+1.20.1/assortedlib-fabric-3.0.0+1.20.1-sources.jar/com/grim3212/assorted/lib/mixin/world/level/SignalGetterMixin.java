package com.grim3212.assorted.lib.mixin.world.level;

import com.grim3212.assorted.lib.core.block.IBlockExtraProperties;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_8235;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_8235.class)
public interface SignalGetterMixin {

    private class_8235 getInternalMixinTarget() {
        return (class_8235) this;
    }

    @Inject(
            method = "getSignal",
            at = @At("HEAD"),
            cancellable = true
    )
    public default void assortedlib_checkForWorldlySignalBlock(class_2338 blockPos, class_2350 direction, CallbackInfoReturnable<Integer> cir) {
        final class_2680 blockState = getInternalMixinTarget().method_8320(blockPos);
        if (blockState.method_26204() instanceof IBlockExtraProperties extraProperties) {
            final boolean shouldCheck = extraProperties.shouldCheckWeakPower(blockState, getInternalMixinTarget(), blockPos, direction);

            final int signal = blockState.method_26195(getInternalMixinTarget(), blockPos, direction);
            cir.setReturnValue(shouldCheck ? Math.max(signal, getInternalMixinTarget().method_49809(blockPos)) : signal);
        }
    }
}
