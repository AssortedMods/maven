package com.grim3212.assorted.lib.mixin.world.level.lighting;

import com.grim3212.assorted.lib.core.block.IBlockLightEmission;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3558.class)
public class LightEngineMixin {

    @Inject(method = "hasDifferentLightProperties", at = @At("HEAD"), cancellable = true)
    private static void assortedlib_onHasDifferentLightProperties(class_1922 blockGetter, class_2338 blockPos, class_2680 oldState, class_2680 newState, CallbackInfoReturnable<Boolean> cir) {
        if (oldState == newState) {
            return;
        }

        if (!(oldState.method_26204() instanceof IBlockLightEmission)) {
            if (!(newState.method_26204() instanceof IBlockLightEmission)) {
                return;
            }
        }

        final int oldLight = oldState.method_26204() instanceof IBlockLightEmission oldLightEmission ? oldLightEmission.getLightEmission(oldState, blockGetter, blockPos) : oldState.method_26213();

        if (!(newState.method_26204() instanceof final IBlockLightEmission newWithWorldlyProperties)) {
            cir.setReturnValue(newState.method_26193(blockGetter, blockPos) != oldState.method_26193(blockGetter, blockPos) || newState.method_26213() != oldLight || newState.method_26211() || oldState.method_26211());
            return;
        }

        cir.setReturnValue(newState.method_26193(blockGetter, blockPos) != oldState.method_26193(blockGetter, blockPos) || newWithWorldlyProperties.getLightEmission(newState, blockGetter, blockPos) != oldLight || newState.method_26211() || oldState.method_26211());
    }
}
