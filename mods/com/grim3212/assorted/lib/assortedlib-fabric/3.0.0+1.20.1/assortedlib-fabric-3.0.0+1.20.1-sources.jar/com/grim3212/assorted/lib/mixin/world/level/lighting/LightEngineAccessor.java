package com.grim3212.assorted.lib.mixin.world.level.lighting;

import net.minecraft.class_2823;
import net.minecraft.class_3556;
import net.minecraft.class_3558;
import net.minecraft.class_3560;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_3558.class)
public interface LightEngineAccessor<M extends class_3556<M>, S extends class_3560<M>> {

    @Accessor
    class_2823 getChunkSource();

    @Accessor
    S getStorage();

    @Invoker
    void callEnqueueIncrease(long l, long m);
}
