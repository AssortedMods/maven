package com.grim3212.assorted.lib.client.model.loader;

import com.grim3212.assorted.lib.client.model.baked.IDataAwareBakedModel;
import com.grim3212.assorted.lib.client.model.baked.IDelegatingBakedModel;
import com.grim3212.assorted.lib.client.model.data.IBlockModelData;
import com.grim3212.assorted.lib.core.block.IBlockEntityWithModelData;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.MeshBuilder;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.fabricmc.fabric.api.rendering.data.v1.RenderAttachedBlockView;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;

public class FabricBakedModelDelegate implements class_1087, IDelegatingBakedModel, FabricBakedModel {
    private final class_1087 delegate;

    public FabricBakedModelDelegate(final class_1087 delegate) {
        this.delegate = delegate;
    }

    @Override
    public List<class_777> method_4707(
            @Nullable final class_2680 state, @Nullable final class_2350 direction, final @NotNull class_5819 random) {
        return delegate.method_4707(state, direction, random);
    }

    @Override
    public boolean method_4708() {
        return delegate.method_4708();
    }

    @Override
    public boolean method_4712() {
        return delegate.method_4712();
    }

    @Override
    public boolean method_24304() {
        return delegate.method_24304();
    }

    @Override
    public boolean method_4713() {
        return delegate.method_4713();
    }

    @Override
    public class_1058 method_4711() {
        return delegate.method_4711();
    }

    @Override
    public class_809 method_4709() {
        return delegate.method_4709();
    }

    @Override
    public class_806 method_4710() {
        return delegate.method_4710();
    }

    @Override
    public class_1087 getDelegate() {
        return delegate;
    }

    @Override
    public boolean isVanillaAdapter() {
        return false;
    }

    @Override
    public void emitBlockQuads(
            final class_1920 blockAndTintGetter, final class_2680 blockState, final class_2338 blockPos, final Supplier<class_5819> supplier, final RenderContext renderContext) {
        if (!(getDelegate() instanceof final IDataAwareBakedModel dataAwareBakedModel)) {
            if (getDelegate() instanceof FabricBakedModel) {
                ((FabricBakedModel) getDelegate()).emitBlockQuads(blockAndTintGetter, blockState, blockPos, supplier, renderContext);
            } else {
                renderContext.fallbackConsumer().accept(getDelegate());
            }

            return;
        }

        Object attachmentData = null;
        if (blockAndTintGetter instanceof RenderAttachedBlockView renderAttachedBlockView) {
            attachmentData = renderAttachedBlockView.getBlockEntityRenderAttachment(blockPos);
        }

        IBlockModelData blockModelData;
        if (attachmentData instanceof IBlockModelData blockModelDataAttachment) {
            blockModelData = blockModelDataAttachment;
        } else {
            final class_2586 blockEntity = blockAndTintGetter.method_8321(blockPos);
            if (!(blockEntity instanceof IBlockEntityWithModelData) || !(getDelegate() instanceof IDataAwareBakedModel)) {
                renderContext.fallbackConsumer().accept(getDelegate());
                return;
            }

            blockModelData = ((IBlockEntityWithModelData) blockEntity).getBlockModelData();
        }

        emitBlockQuads(dataAwareBakedModel, blockModelData, blockState, blockPos, supplier, renderContext);
    }

    public void emitBlockQuads(
            final IDataAwareBakedModel dataAwareBakedModel, final IBlockModelData blockModelData, final class_2680 blockState, final class_2338 blockPos, final Supplier<class_5819> supplier, final RenderContext renderContext) {
        final Collection<class_1921> renderTypes = dataAwareBakedModel.getSupportedRenderTypes(blockState, supplier.get(), blockModelData);

        for (class_2350 direction : class_2350.values()) {
            renderTypes.forEach(renderType -> emitBlockQuads(dataAwareBakedModel, blockModelData, blockState, blockPos, direction, supplier, renderContext, renderType));
        }

        renderTypes.forEach(renderType -> emitBlockQuads(dataAwareBakedModel, blockModelData, blockState, blockPos, null, supplier, renderContext, renderType));
    }

    public void emitBlockQuads(
            final IDataAwareBakedModel dataAwareBakedModel, final IBlockModelData blockModelData, final class_2680 blockState, final class_2338 blockPos, final class_2350 direction, final Supplier<class_5819> supplier, final RenderContext renderContext, class_1921 renderType) {
        final List<class_777> quads = dataAwareBakedModel.getQuads(blockState, direction, supplier.get(), blockModelData, renderType);

        final RenderMaterial material = Objects.requireNonNull(RendererAccess.INSTANCE.getRenderer()).materialFinder().blendMode(0, BlendMode.fromRenderLayer(renderType)).find();

        quads.forEach(quad -> {
            final MeshBuilder meshBuilder = RendererAccess.INSTANCE.getRenderer().meshBuilder();
            final QuadEmitter emitter = meshBuilder.getEmitter();
            emitter.fromVanilla(quad, material, direction);
            emitter.emit();
            renderContext.meshConsumer().accept(meshBuilder.build());
        });
    }

    @Override
    public void emitItemQuads(final class_1799 itemStack, final Supplier<class_5819> supplier, final RenderContext renderContext) {
        if (!(getDelegate() instanceof final IDataAwareBakedModel dataAwareBakedModel)) {
            if (getDelegate() instanceof FabricBakedModel) {
                ((FabricBakedModel) getDelegate()).emitItemQuads(itemStack, supplier, renderContext);
            } else {
                renderContext.fallbackConsumer().accept(getDelegate());
            }

            return;
        }

        emitItemQuads(dataAwareBakedModel, itemStack, supplier, renderContext, false);
    }

    public void emitItemQuads(
            final IDataAwareBakedModel dataAwareBakedModel, final class_1799 itemStack, final Supplier<class_5819> supplier, final RenderContext renderContext, final boolean isFabulous) {
        final Collection<class_1921> renderTypes = dataAwareBakedModel.getSupportedRenderTypes(itemStack, isFabulous);

        renderTypes.forEach(renderType -> emitItemQuads(dataAwareBakedModel, itemStack, supplier, renderContext, isFabulous, renderType));
    }

    public void emitItemQuads(final IDataAwareBakedModel dataAwareBakedModel, final class_1799 itemStack, final Supplier<class_5819> supplier, final RenderContext renderContext, final boolean isFabulous, final class_1921 renderType) {
        final List<class_777> quads = dataAwareBakedModel.getQuads(itemStack, isFabulous, supplier.get(), renderType);
        final RenderMaterial material = Objects.requireNonNull(RendererAccess.INSTANCE.getRenderer()).materialFinder().blendMode(0, renderType).find();

        quads.forEach(quad -> {
            final MeshBuilder meshBuilder = RendererAccess.INSTANCE.getRenderer().meshBuilder();
            final QuadEmitter emitter = meshBuilder.getEmitter();
            emitter.fromVanilla(quad, material, null);
            emitter.emit();
            renderContext.meshConsumer().accept(meshBuilder.build());
        });
    }

    @FunctionalInterface
    private interface QuadGetter {

        List<class_777> getQuads(class_2680 blockState, class_2350 side, class_5819 rand);
    }

    private static final class QuadDelegatingBakedModel extends ForwardingBakedModel {
        private final QuadGetter quadGetter;

        private QuadDelegatingBakedModel(
                final class_1087 delegate,
                final QuadGetter quadGetter) {
            this.quadGetter = quadGetter;
            this.wrapped = delegate;
        }

        @Override
        public List<class_777> method_4707(@Nullable final class_2680 blockState, @Nullable final class_2350 direction, final class_5819 random) {
            return quadGetter.getQuads(blockState, direction, random);
        }
    }
}
