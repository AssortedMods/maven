package com.grim3212.assorted.lib.mixin.world.entity;

import com.grim3212.assorted.lib.core.block.IBlockExtraProperties;
import com.grim3212.assorted.lib.core.block.IBlockSoundType;
import com.grim3212.assorted.lib.core.block.effects.IBlockLandingEffects;
import com.grim3212.assorted.lib.mixin.entity.EntityAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@SuppressWarnings("InvalidInjectorMethodSignature")
@Mixin(class_1309.class)
public abstract class LivingEntityWorldlyBlockMixin extends class_1297 {
    public LivingEntityWorldlyBlockMixin(final class_1299<?> entityType, final class_1937 level) {
        super(entityType, level);
    }

    @ModifyVariable(
            method = "travel",
            slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getBlockPosBelowThatAffectsMyMovement()Lnet/minecraft/core/BlockPos;")),
            at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/world/level/block/Block;getFriction()F"), ordinal = 0
    )
    private float assortedlib_rewriteFrictionValueForWorldlyBlocks(float original) {
        if (!(this instanceof EntityAccessor entityAccessor))
            return original;

        final class_2338 pos = this.method_23314();
        final class_2680 blockState = entityAccessor.getLevel().method_8320(pos);
        if (blockState.method_26204() instanceof IBlockExtraProperties extraProperties) {
            return extraProperties.getFriction(blockState, entityAccessor.getLevel(), pos, this);
        }

        return original;
    }


    @SuppressWarnings("InvalidInjectorMethodSignature")
    @ModifyVariable(
            method = "playBlockFallSound",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;getSoundType()Lnet/minecraft/world/level/block/SoundType;"
            ),
            ordinal = 0
    )
    private class_2498 assortedlib_injectGetBlockStateSoundType(final class_2498 current) {
        if (!(this instanceof EntityAccessor entityAccessor))
            return current;

        int i = class_3532.method_15357(this.method_23317());
        int j = class_3532.method_15357(this.method_23318() - (double) 0.2F);
        int k = class_3532.method_15357(this.method_23321());
        final class_2338 pos = new class_2338(i, j, k);
        class_2680 blockState = entityAccessor.getLevel().method_8320(pos);

        if (blockState.method_26204() instanceof IBlockSoundType extraProperties) {
            return extraProperties.getSoundType(blockState, entityAccessor.getLevel(), pos, this);
        }
        return current;
    }

    @Inject(
            method = "checkFallDamage",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/level/ServerLevel;sendParticles(Lnet/minecraft/core/particles/ParticleOptions;DDDIDDDD)I",
                    shift = At.Shift.BEFORE
            ),
            locals = LocalCapture.CAPTURE_FAILHARD,
            cancellable = true
    )
    protected void assortedlib_checkFallEffects(double y, boolean onGround, class_2680 state, class_2338 pos, CallbackInfo ci, double d, double e, double f, class_2338 blockPos, float j, double k, int count) {
        if (!(this instanceof EntityAccessor entityAccessor))
            return;

        if (state.method_26204() instanceof IBlockLandingEffects extraProps && extraProps.addLandingEffects(state, (class_3218) entityAccessor.getLevel(), pos, state, (class_1309) (Object) this, count)) {
            super.method_5623(y, onGround, state, pos);
            ci.cancel();
        }
    }
}
