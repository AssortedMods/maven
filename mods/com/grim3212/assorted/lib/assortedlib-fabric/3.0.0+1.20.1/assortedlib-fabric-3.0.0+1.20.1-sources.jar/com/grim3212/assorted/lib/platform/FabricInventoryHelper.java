package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.core.inventory.IInventoryBlockEntity;
import com.grim3212.assorted.lib.core.inventory.IInventoryItem;
import com.grim3212.assorted.lib.core.inventory.IItemStorageHandler;
import com.grim3212.assorted.lib.core.inventory.IPlatformInventoryStorageHandler;
import com.grim3212.assorted.lib.inventory.FabricPlatformInventoryStorageHandlerSided;
import com.grim3212.assorted.lib.inventory.FabricPlatformInventoryStorageHandlerUnsided;
import com.grim3212.assorted.lib.inventory.FabricWrappedItemHandler;
import com.grim3212.assorted.lib.platform.services.IInventoryHelper;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.function.Function;

public class FabricInventoryHelper implements IInventoryHelper {
    @Override
    public boolean canItemStacksStack(@NotNull class_1799 a, @NotNull class_1799 b) {
        if (a.method_7960() || !class_1799.method_7984(a, b) || a.method_7985() != b.method_7985())
            return false;

        return (!a.method_7985() || a.method_7969().equals(b.method_7969()));
    }

    @Override
    public class_1799 copyStackWithSize(@NotNull class_1799 itemStack, int size) {
        if (size == 0)
            return class_1799.field_8037;
        class_1799 copy = itemStack.method_7972();
        copy.method_7939(size);
        return copy;
    }

    @Override
    public Optional<IItemStorageHandler> getItemStorageHandler(class_1799 stack) {
        if (stack.method_7960())
            return Optional.empty();

        if (stack.method_7909() instanceof IInventoryItem itemStackStorage) {
            IPlatformInventoryStorageHandler storageHandler = itemStackStorage.getStorageHandler(stack);
            if (storageHandler != null) {
                return Optional.of(storageHandler.getItemStorageHandler(null));
            }
        }

        return Optional.empty();
    }

    @Override
    public Optional<IItemStorageHandler> getItemStorageHandler(class_2586 blockEntity, @Nullable class_2350 direction) {
        if (blockEntity == null || blockEntity.method_11015())
            return Optional.empty();

        if (blockEntity instanceof IInventoryBlockEntity inventoryBlockEntity) {
            IPlatformInventoryStorageHandler storageHandler = inventoryBlockEntity.getStorageHandler();
            if (storageHandler != null) {
                return Optional.of(storageHandler.getItemStorageHandler(direction));
            }
        }

        Storage<ItemVariant> inventory = ItemStorage.SIDED.find(blockEntity.method_10997(), blockEntity.method_11016(), direction);
        if (inventory != null && inventory instanceof InventoryStorage inventoryStorage) {
            // TODO: Look into supporting the base Storage<ItemVariant>
            return Optional.of(new FabricWrappedItemHandler(blockEntity, inventoryStorage));
        }

        if (blockEntity instanceof class_1263 container) {
            return Optional.of(new FabricWrappedItemHandler(blockEntity, InventoryStorage.of(container, direction)));
        }

        return Optional.empty();
    }

    @Override
    public IPlatformInventoryStorageHandler createStorageInventoryHandler(IItemStorageHandler handler) {
        return new FabricPlatformInventoryStorageHandlerUnsided(handler);
    }

    @Override
    public IPlatformInventoryStorageHandler createSidedStorageInventoryHandler(Function<class_2350, IItemStorageHandler> handler) {
        return new FabricPlatformInventoryStorageHandlerSided(handler);
    }
}
