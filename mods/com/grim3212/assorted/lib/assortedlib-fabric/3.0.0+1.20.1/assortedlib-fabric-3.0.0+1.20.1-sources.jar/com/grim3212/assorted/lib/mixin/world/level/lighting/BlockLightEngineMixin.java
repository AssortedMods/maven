package com.grim3212.assorted.lib.mixin.world.level.lighting;

import com.grim3212.assorted.lib.core.block.IBlockLightEmission;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2823;
import net.minecraft.class_3552;
import net.minecraft.class_3556;
import net.minecraft.class_3558;
import net.minecraft.class_3560;
import net.minecraft.class_4076;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3552.class)
public abstract class BlockLightEngineMixin<M extends class_3556<M>, S extends class_3560<M>> extends class_3558<M, S> {

    @Shadow
    @Final
    private class_2338.class_2339 mutablePos;

    @Unique
    private static ThreadLocal<class_3552> INSTANCE = new ThreadLocal<>();

    protected BlockLightEngineMixin(class_2823 lightChunkGetter, S layerLightSectionStorage) {
        super(lightChunkGetter, layerLightSectionStorage);
    }

    @Inject(method = "getEmission", at = @At("HEAD"), cancellable = true)
    public void assortedlib_onGetEmission(long packedPos, class_2680 blockState, CallbackInfoReturnable<Integer> cir) {
        if (!(this instanceof LightEngineAccessor<?, ?> lightEngineAccessor)) {
            return;
        }

        if (!(lightEngineAccessor.getStorage() instanceof LayerLightSectionStorageAccessor<?> layerLightSectionStorageAccessor)) {
            return;
        }

        if (!(blockState.method_26204() instanceof IBlockLightEmission blockWithWorldlyProperties)) {
            return;
        }

        final int lightEmission = blockWithWorldlyProperties.getLightEmission(blockState, lightEngineAccessor.getChunkSource().method_16399(), mutablePos);
        cir.setReturnValue(lightEmission > 0 && layerLightSectionStorageAccessor.callLightOnInSection(class_4076.method_18691(packedPos)) ? lightEmission : 0);
    }

    @Inject(method = "propagateLightSources", at = @At("HEAD"))
    private void assortedlib_onPropagateLightSourcesCall(class_1923 chunkPos, CallbackInfo ci) {
        INSTANCE.set((class_3552) (Object) this);
    }

    @Inject(method = "propagateLightSources", at = @At("RETURN"))
    private void assortedlib_onPropagateLightSourcesEnd(class_1923 chunkPos, CallbackInfo ci) {
        INSTANCE.remove();
    }

    @Inject(method = "method_51532", remap = false, at = @At("HEAD"), cancellable = true)
    private void assortedlib_onCallPropagateLightSourcesCallback(class_2338 blockPos, class_2680 blockState, CallbackInfo ci) {
        if (!(blockState.method_26204() instanceof IBlockLightEmission blockWithWorldlyProperties)) {
            return;
        }

        final Object currentInstance = INSTANCE.get();
        if (currentInstance == null) {
            return;
        }

        //noinspection ConstantValue
        if (!(currentInstance instanceof LightEngineAccessor<?, ?> lightEngineAccessor)) {
            return;
        }

        int lightEmission = blockWithWorldlyProperties.getLightEmission(blockState, lightEngineAccessor.getChunkSource().method_16399(), blockPos);
        lightEngineAccessor.callEnqueueIncrease(blockPos.method_10063(), class_3558.class_8531.method_51573(lightEmission, method_51563(blockState)));

        ci.cancel();
    }
}
