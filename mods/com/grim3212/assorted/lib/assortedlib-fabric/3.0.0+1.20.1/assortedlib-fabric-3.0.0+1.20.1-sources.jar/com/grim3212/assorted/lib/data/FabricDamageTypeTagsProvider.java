package com.grim3212.assorted.lib.data;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_8142;

public class FabricDamageTypeTagsProvider extends class_8142 {
    private final LibDamageTypeTagsProvider commonTags;

    public FabricDamageTypeTagsProvider(class_7784 output, CompletableFuture<class_7225.class_7874> lookup, LibDamageTypeTagsProvider commonTags) {
        super(output, lookup);
        this.commonTags = commonTags;
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        this.commonTags.addCommonTags(this::method_10512);
    }
}
