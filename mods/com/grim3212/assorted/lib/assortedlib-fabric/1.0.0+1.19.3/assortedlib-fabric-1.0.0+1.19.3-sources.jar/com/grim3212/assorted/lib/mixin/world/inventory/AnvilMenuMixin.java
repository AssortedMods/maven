package com.grim3212.assorted.lib.mixin.world.inventory;

import com.grim3212.assorted.lib.events.AnvilUpdatedEvent;
import com.grim3212.assorted.lib.platform.Services;
import net.minecraft.class_1661;
import net.minecraft.class_1706;
import net.minecraft.class_1799;
import net.minecraft.class_3914;
import net.minecraft.class_3915;
import net.minecraft.class_3917;
import net.minecraft.class_4861;
import net.minecraft.world.inventory.*;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1706.class)
public abstract class AnvilMenuMixin extends class_4861 {

    @Shadow
    @Final
    private class_3915 cost;

    @Shadow
    private String itemName;

    @Shadow
    private int repairItemCountCost;

    public AnvilMenuMixin(@Nullable class_3917<?> menuType, int i, class_1661 inventory, class_3914 containerLevelAccess) {
        super(menuType, i, inventory, containerLevelAccess);
    }

    @Inject(method = "createResult", at = @At("HEAD"), cancellable = true)
    private void assortedlib_checkForResults(CallbackInfo ci) {
        class_1799 leftSlot = field_22480.method_5438(0);
        class_1799 rightSlot = field_22480.method_5438(1);
        int baseCost = leftSlot.method_7928() + (rightSlot.method_7960() ? 0 : rightSlot.method_7928());

        final AnvilUpdatedEvent event = new AnvilUpdatedEvent(leftSlot, rightSlot, itemName, baseCost, this.field_22482);
        Services.EVENTS.handleEvents(event);

        if (event.isCanceled()) {
            // Canceled so just return empty
            this.field_22479.method_5447(0, class_1799.field_8037);
            this.cost.method_17404(0);
            ci.cancel();
        } else if (!event.getOutput().method_7960()) {
            this.field_22479.method_5447(0, event.getOutput());
            this.cost.method_17404(event.getCost());
            this.repairItemCountCost = event.getMaterialCost();
            ci.cancel();
        }
    }
}
