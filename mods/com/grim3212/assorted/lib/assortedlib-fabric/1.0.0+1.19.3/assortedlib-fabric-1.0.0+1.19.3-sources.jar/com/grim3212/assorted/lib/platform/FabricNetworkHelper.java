package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.platform.services.INetworkHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class FabricNetworkHelper implements INetworkHelper {

    private static final Map<Class<?>, MessageHandler<?>> messageHandlers = new ConcurrentHashMap<>();
    private static final List<MessageHandler<?>> clientMessageHandlers = new ArrayList<>();
    private static class_1657 replyPlayer;

    @Override
    public <MSG> void register(MessageHandler<MSG> handler) {
        messageHandlers.put(handler.messageType(), handler);

        if (handler.side() == MessageBoundSide.CLIENT) {
            clientMessageHandlers.add(handler);
            return;
        }

        ServerPlayNetworking.registerGlobalReceiver(handler.id(), ((server, player, listener, buf, responseSender) -> {
            MSG message = handler.decoder().apply(buf);
            server.execute(() -> {
                replyPlayer = player;
                handler.messageConsumer().accept(message, player);
                replyPlayer = null;
            });
        }));
    }

    public static void initializeClientHandlers() {
        for (MessageHandler<?> handler : clientMessageHandlers) {
            registerClientReceiver(handler);
        }
    }

    private static <MSG> void registerClientReceiver(MessageHandler<MSG> handler) {
        ClientPlayNetworking.registerGlobalReceiver(handler.id(), ((client, listener, buf, responseSender) -> {
            MSG message = handler.decoder().apply(buf);
            client.execute(() -> handler.messageConsumer().accept(message, class_310.method_1551().field_1724));
        }));
    }

    @Override
    public <MSG> void sendToNearby(class_1937 world, class_2338 pos, MSG toSend) {
        if (world instanceof class_3218) {
            MessageHandler<MSG> handler = (MessageHandler<MSG>) messageHandlers.get(toSend.getClass());

            class_3218 ws = (class_3218) world;
            class_2540 buf = PacketByteBufs.create();
            handler.encoder().accept(toSend, buf);
            ws.method_14178().field_17254.method_17210(new class_1923(pos), false).stream().filter(p -> p.method_5649(pos.method_10263(), pos.method_10264(), pos.method_10260()) < 64 * 64).forEach(p -> ServerPlayNetworking.send(p, handler.id(), buf));
        }
    }

    @Override
    public <MSG> void sendToNearby(class_1937 world, class_1297 entity, MSG toSend) {
        sendToNearby(world, entity.method_24515(), toSend);
    }

    @Override
    public <MSG> void sendTo(class_1657 player, MSG toSend) {
        MessageHandler<MSG> handler = (MessageHandler<MSG>) messageHandlers.get(toSend.getClass());
        class_2540 buf = PacketByteBufs.create();
        handler.encoder().accept(toSend, buf);
        ServerPlayNetworking.send((class_3222) player, handler.id(), buf);
    }

    @Override
    public <MSG> void sendToServer(MSG toSend) {
        MessageHandler<MSG> handler = (MessageHandler<MSG>) messageHandlers.get(toSend.getClass());
        class_2540 buf = PacketByteBufs.create();
        handler.encoder().accept(toSend, buf);
        ClientPlayNetworking.send(handler.id(), buf);
    }
}
