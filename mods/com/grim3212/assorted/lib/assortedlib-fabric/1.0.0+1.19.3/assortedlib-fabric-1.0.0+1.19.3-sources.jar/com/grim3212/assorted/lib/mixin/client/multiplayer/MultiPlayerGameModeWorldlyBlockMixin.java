package com.grim3212.assorted.lib.mixin.client.multiplayer;

import com.grim3212.assorted.lib.core.block.IBlockOnPlayerBreak;
import com.grim3212.assorted.lib.core.block.IBlockSoundType;
import com.grim3212.assorted.lib.events.EntityInteractEvent;
import com.grim3212.assorted.lib.platform.Services;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_636.class)
public abstract class MultiPlayerGameModeWorldlyBlockMixin {

    @Shadow
    @Final
    private class_310 minecraft;

    @SuppressWarnings("InvalidInjectorMethodSignature")
    @ModifyVariable(
            method = "continueDestroyBlock",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;getSoundType()Lnet/minecraft/world/level/block/SoundType;"
            ),
            ordinal = 0
    )
    private class_2498 assortedlib_injectGetBlockStateSoundType(final class_2498 current, class_2338 pPosBlock, class_2350 pDirectionFacing) {
        final class_2680 blockState = minecraft.field_1687.method_8320(pPosBlock);
        if (blockState.method_26204() instanceof IBlockSoundType extraProperties) {
            return extraProperties.getSoundType(blockState, class_310.method_1551().field_1687, pPosBlock, class_310.method_1551().field_1724);
        }
        return current;
    }

    @Inject(method = "interact",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/ClientPacketListener;send(Lnet/minecraft/network/protocol/Packet;)V",
                    shift = At.Shift.AFTER),
            cancellable = true)
    private void assortedlib_entityInteract(class_1657 player, class_1297 entity, class_1268 interactionHand, CallbackInfoReturnable<class_1269> cir) {
        final EntityInteractEvent event = new EntityInteractEvent(player, interactionHand, entity);
        Services.EVENTS.handleEvents(event);

        if (event.getInteractionResult() == class_1269.field_5812) {
            cir.setReturnValue(class_1269.field_5812);
        }
    }

    @Inject(method = "destroyBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/Block;playerWillDestroy(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/entity/player/Player;)V"), locals = LocalCapture.CAPTURE_FAILHARD, cancellable = true)
    public void assortedlib_onDestroyedByPlayer(class_2338 pos, CallbackInfoReturnable<Boolean> cir, class_1937 level, class_2680 blockState, class_2248 block) {
        if (blockState.method_26204() instanceof IBlockOnPlayerBreak extraProperties) {
            class_3610 fluidstate = level.method_8316(pos);
            boolean flag = extraProperties.onDestroyedByPlayer(blockState, level, pos, minecraft.field_1724, false, fluidstate);
            if (flag) {
                block.method_9585(level, pos, blockState);
            }

            cir.setReturnValue(flag);
        }
    }
}
