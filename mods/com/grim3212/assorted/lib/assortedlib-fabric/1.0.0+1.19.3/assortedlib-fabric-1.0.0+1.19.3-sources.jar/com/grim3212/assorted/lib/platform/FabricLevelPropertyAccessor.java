package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.core.block.*;
import com.grim3212.assorted.lib.platform.services.ILevelPropertyAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3620;
import net.minecraft.class_4538;
import org.jetbrains.annotations.Nullable;

public class FabricLevelPropertyAccessor implements ILevelPropertyAccessor {
    @Override
    public boolean shouldCheckWeakPower(class_4538 levelReader, class_2338 blockPos, class_2350 direction) {
        final class_2680 blockState = levelReader.method_8320(blockPos);
        if (blockState.method_26204() instanceof IBlockExtraProperties extraProperties) {
            return extraProperties.shouldCheckWeakPower(blockState, levelReader, blockPos, direction);
        }

        return blockState.method_26212(levelReader, blockPos);
    }

    @Override
    public float getFriction(class_4538 levelReader, class_2338 blockPos, @Nullable class_1297 entity) {
        final class_2680 blockState = levelReader.method_8320(blockPos);
        if (blockState.method_26204() instanceof IBlockExtraProperties extraProperties) {
            return extraProperties.getFriction(blockState, levelReader, blockPos, entity);
        }

        return blockState.method_26204().method_9499();
    }

    @Override
    public int getLightEmission(class_1922 getter, class_2338 blockPos) {
        final class_2680 blockState = getter.method_8320(blockPos);
        if (blockState.method_26204() instanceof IBlockLightEmission extraProperties) {
            return extraProperties.getLightEmission(blockState, getter, blockPos);
        }

        return blockState.method_26213();
    }

    @Override
    public boolean canHarvestBlock(class_1922 blockGetter, class_2338 blockPos, class_1657 player) {
        final class_2680 blockState = blockGetter.method_8320(blockPos);
        if (blockState.method_26204() instanceof IBlockCanHarvest extraProperties) {
            return extraProperties.canHarvestBlock(blockState, blockGetter, blockPos, player);
        }

        return player.method_7305(blockState);
    }

    @Override
    public class_2498 getSoundType(class_4538 levelReader, class_2338 blockPos, class_1297 entity) {
        final class_2680 blockState = levelReader.method_8320(blockPos);
        if (blockState.method_26204() instanceof IBlockSoundType extraProperties) {
            return extraProperties.getSoundType(blockState, levelReader, blockPos, entity);
        }

        return blockState.method_26231();
    }

    @Override
    public float getExplosionResistance(class_1922 blockGetter, class_2338 blockPos, class_1927 explosion) {
        final class_2680 blockState = blockGetter.method_8320(blockPos);
        if (blockState.method_26204() instanceof IBlockExtraProperties extraProperties) {
            return extraProperties.getExplosionResistance(blockState, blockGetter, blockPos, explosion);
        }

        return blockState.method_26204().method_9520();
    }

    @Override
    public class_1799 getCloneItemStack(class_2680 state, class_239 target, class_1922 blockGetter, class_2338 pos, class_1657 player) {
        if (state.method_26204() instanceof IBlockCloneStack extraProperties) {
            return extraProperties.getCloneItemStack(state, target, blockGetter, pos, player);
        }
        return state.method_26204().method_9574(blockGetter, pos, state);
    }

    @Override
    public class_3620 getMapColor(class_2680 state, class_1922 level, class_2338 pos, class_3620 defaultColor) {
        if (state.method_26204() instanceof IBlockMapColor extraProperties) {
            return extraProperties.getMapColor(state, level, pos, defaultColor);
        }
        return state.method_26205(level, pos);
    }
}
