package com.grim3212.assorted.lib.inventory;

import com.grim3212.assorted.lib.core.inventory.IItemStorageHandler;
import com.grim3212.assorted.lib.platform.Services;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleSlotStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1799;
import net.minecraft.class_2586;
import org.jetbrains.annotations.NotNull;

public class FabricWrappedItemHandler implements IItemStorageHandler {

    private final InventoryStorage storage;
    private final class_2586 entity;

    public FabricWrappedItemHandler(class_2586 entity, @NotNull InventoryStorage storage) {
        this.storage = storage;
        this.entity = entity;
    }

    @Override
    public int getSlots() {
        return this.storage.getSlots().size();
    }

    @Override
    public @NotNull class_1799 getStackInSlot(int slot) {
        SingleSlotStorage<ItemVariant> slotStorage = this.storage.getSlot(slot);
        return slotStorage.getResource().toStack((int) slotStorage.getAmount());
    }

    @Override
    public @NotNull class_1799 insertItem(int slot, @NotNull class_1799 stack, boolean simulate) {
        SingleSlotStorage<ItemVariant> slotStorage = this.storage.getSlot(slot);
        if (!slotStorage.supportsInsertion() || stack.method_7960()) {
            return stack;
        }

        if (!slotStorage.isResourceBlank() && !Services.INVENTORY.canItemStacksStack(stack, slotStorage.getResource().toStack((int) slotStorage.getAmount()))) {
            return stack;
        }

        ItemVariant toInsert = ItemVariant.of(stack);
        if (simulate) {
            int inserted = (int) slotStorage.simulateInsert(toInsert, stack.method_7947(), null);
            if (inserted <= 0) {
                return stack;
            } else {
                int remainder = stack.method_7947() - inserted;
                if (remainder > 0) {
                    return stack.method_46651(remainder);
                }
                return class_1799.field_8037;
            }
        }

        try (final Transaction context = Transaction.openOuter()) {
            int inserted = (int) slotStorage.insert(toInsert, stack.method_7947(), context);
            context.commit();
            if (inserted <= 0) {
                return stack;
            } else {
                int remainder = stack.method_7947() - inserted;
                if (remainder > 0) {
                    return stack.method_46651(remainder);
                }
                return class_1799.field_8037;
            }
        }
    }

    @Override
    public @NotNull class_1799 extractItem(int slot, int amount, boolean simulate) {
        SingleSlotStorage<ItemVariant> slotStorage = this.storage.getSlot(slot);
        if (!slotStorage.supportsExtraction() || amount < 0) {
            return class_1799.field_8037;
        }

        ItemVariant variant = slotStorage.getResource();
        if (variant.isBlank()) {
            return class_1799.field_8037;
        }

        if (simulate) {
            int extracted = (int) slotStorage.simulateExtract(variant, amount, null);
            if (extracted <= 0) {
                return class_1799.field_8037;
            } else {
                return slotStorage.getResource().toStack(extracted);
            }
        }

        try (final Transaction context = Transaction.openOuter()) {
            class_1799 extractingType = slotStorage.getResource().toStack();
            int extracted = (int) slotStorage.extract(variant, amount, context);
            context.commit();
            if (extracted <= 0) {
                return class_1799.field_8037;
            } else {
                return extractingType.method_46651(extracted);
            }
        }
    }

    @Override
    public int getSlotLimit(int slot) {
        return (int) this.storage.getSlot(slot).getCapacity();
    }

    @Override
    public boolean isItemValid(int slot, @NotNull class_1799 stack) {
        SingleSlotStorage<ItemVariant> slotStorage = this.storage.getSlot(slot);
        return slotStorage.supportsInsertion() && slotStorage.simulateInsert(ItemVariant.of(stack), stack.method_7947(), null) > 0;
    }

    @Override
    public void setStackInSlot(int slot, @NotNull class_1799 stack) {
        SingleSlotStorage<ItemVariant> slotStorage = this.storage.getSlot(slot);
        try (final Transaction context = Transaction.openOuter()) {
            // Extract everything from the slot
            slotStorage.extract(slotStorage.getResource(), slotStorage.getCapacity(), context);
            // Then add the stack in to set
            slotStorage.insert(ItemVariant.of(stack), stack.method_7947(), context);
            context.commit();
        }
    }

    @Override
    public void onContentsChanged(int slot) {
        if (this.entity != null)
            this.entity.method_5431();
    }
}
