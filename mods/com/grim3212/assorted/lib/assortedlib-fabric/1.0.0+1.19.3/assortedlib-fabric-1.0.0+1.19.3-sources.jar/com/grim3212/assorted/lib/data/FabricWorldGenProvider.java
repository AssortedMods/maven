package com.grim3212.assorted.lib.data;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricDynamicRegistryProvider;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class FabricWorldGenProvider extends FabricDynamicRegistryProvider {

    private final LibWorldGenProvider commonWorldGen;
    private final String modId;

    public FabricWorldGenProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture, String modId, LibWorldGenProvider commonWorldGen) {
        super(output, registriesFuture);
        this.commonWorldGen = commonWorldGen;
        this.modId = modId;
    }

    @Override
    protected void configure(class_7225.class_7874 registries, Entries entries) {
        for (class_5321<? extends class_2378<?>> registry : this.commonWorldGen.registries()) {
            entries.addAll(registries.method_46762(registry));
        }
    }

    @Override
    public String method_10321() {
        return this.modId + ", world gen provider";
    }
}
