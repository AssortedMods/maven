package com.grim3212.assorted.lib.mixin.world.item;

import com.grim3212.assorted.lib.core.block.IBlockSoundType;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1747.class)
public abstract class BlockItemWorldlyBlockMixin extends class_1792 {

    @Unique
    private class_2680 soundState;
    @Unique
    private class_2498 soundType;

    public BlockItemWorldlyBlockMixin(final class_1793 properties) {
        super(properties);
    }

    @ModifyVariable(
            method = "place",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/level/Level;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;"
            ),
            ordinal = 0
    )
    private class_2680 assortedlib_injectGetSoundTypeAdaptorForInitialState(final class_2680 current) {
        this.soundState = current;
        return current;
    }

    @ModifyVariable(
            method = "place",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/item/BlockItem;updateBlockStateFromTag(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/level/block/state/BlockState;"
            ),
            ordinal = 0
    )
    private class_2680 assortedlib_injectGetSoundTypeAdaptorForTagUpdate(final class_2680 current) {
        this.soundState = current;
        return current;
    }


    @SuppressWarnings("InvalidInjectorMethodSignature")
    @ModifyVariable(
            method = "place",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;getSoundType()Lnet/minecraft/world/level/block/SoundType;"
            ),
            ordinal = 0
    )
    private class_2498 assortedlib_injectGetSoundTypeAdaptor(final class_2498 current, class_1750 blockPlaceContext) {
        if (soundState.method_26204() instanceof IBlockSoundType extraProperties) {
            this.soundType = extraProperties.getSoundType(soundState, blockPlaceContext.method_8045(), blockPlaceContext.method_8037(), blockPlaceContext.method_8036());
            return this.soundType;
        }
        this.soundType = null;
        return current;
    }

    @Inject(
            method = "getPlaceSound",
            at = @At(
                    value = "HEAD"
            ),
            cancellable = true)
    public void assortedlib_redirectGetBlockStateSoundTypePlace(final class_2680 state, final CallbackInfoReturnable<class_3414> cir) {
        if (this.soundType != null) {
            cir.setReturnValue(this.soundType.method_10598());
        }
    }
}
