package com.grim3212.assorted.lib.mixin.client.render;

import com.grim3212.assorted.lib.core.block.IBlockLightEmission;
import com.grim3212.assorted.lib.core.block.IBlockSoundType;
import net.minecraft.class_1920;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4013;
import net.minecraft.class_638;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class LevelRendererWorldlyBlockMixin implements class_4013, AutoCloseable {

    @Shadow
    private class_638 level;

    @Shadow
    public abstract void levelEvent(final int p_234305_, final class_2338 p_234306_, final int p_234307_);

    @Unique
    private int currentEventArgument;
    @Unique
    private class_2338 currentEventPosition;

    @ModifyVariable(
            method = "getLightColor(Lnet/minecraft/world/level/BlockAndTintGetter;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;)I",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;getLightEmission()I"
            ),
            ordinal = 0
    )
    private static int assortedlib_injectGetBlockStateSoundType(final int current, class_1920 pLevel, class_2680 pState, class_2338 pPos) {
        final class_2680 blockState = pLevel.method_8320(pPos);
        if (blockState.method_26204() instanceof IBlockLightEmission extraProperties) {
            return extraProperties.getLightEmission(pState, pLevel, pPos);
        }
        return current;
    }

    @Inject(
            method = "levelEvent",
            at = @At("HEAD")
    )
    public void assortedlib_captureEventArguments(final int i, final class_2338 blockPos, final int j, final CallbackInfo ci) {
        currentEventPosition = blockPos;
        currentEventArgument = j;
    }

    @SuppressWarnings("InvalidInjectorMethodSignature")
    @ModifyVariable(
            method = "levelEvent",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;getSoundType()Lnet/minecraft/world/level/block/SoundType;"
            )
    )
    public class_2498 assortedlib_redirectGetBlockStateSoundType(class_2498 current) {
        final class_2680 blockState = class_2248.method_9531(currentEventArgument);
        if (blockState.method_26204() instanceof IBlockSoundType extraProperties) {
            return extraProperties.getSoundType(blockState, this.level, currentEventPosition, class_310.method_1551().field_1719);
        }
        return current;
    }
}
