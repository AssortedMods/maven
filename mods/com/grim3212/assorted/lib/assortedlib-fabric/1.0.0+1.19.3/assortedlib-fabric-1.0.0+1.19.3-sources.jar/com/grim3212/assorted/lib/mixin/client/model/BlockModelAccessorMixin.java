package com.grim3212.assorted.lib.mixin.client.model;

import com.grim3212.assorted.lib.client.model.IBlockModelAccessor;
import com.mojang.datafixers.util.Either;
import net.minecraft.class_2960;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_785;
import net.minecraft.class_793;
import net.minecraft.class_799;
import net.minecraft.class_806;
import net.minecraft.class_809;
import net.minecraft.client.renderer.block.model.*;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;
import java.util.Map;

@Mixin(class_793.class)
public abstract class BlockModelAccessorMixin implements IBlockModelAccessor {
    @Shadow
    public String name;
    @Shadow
    @Final
    protected Map<String, Either<class_4730, String>> textureMap;
    @Shadow
    @Nullable
    protected class_793 parent;
    @Shadow
    @Nullable
    protected class_2960 parentLocation;

    @Shadow
    protected abstract class_806 getItemOverrides(class_7775 baker, class_793 model);

    @Shadow
    public abstract List<class_785> getElements();

    @Shadow
    public abstract class_793.class_4751 getGuiLight();

    @Shadow
    public abstract boolean hasAmbientOcclusion();

    @Shadow
    public abstract class_809 getTransforms();

    @Shadow
    public abstract List<class_799> getOverrides();

    @Override
    public List<class_785> elements() {
        return getElements();
    }

    @Override
    public class_793.class_4751 guiLight() {
        return getGuiLight();
    }

    @Override
    public boolean usesAmbientOcclusion() {
        return hasAmbientOcclusion();
    }

    @Override
    public class_809 transforms() {
        return getTransforms();
    }

    @Override
    public List<class_799> overrides() {
        return getOverrides();
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public Map<String, Either<class_4730, String>> textureMap() {
        return textureMap;
    }

    @Override
    public class_793 parent() {
        return parent;
    }

    @Override
    public class_2960 parentLocation() {
        return parentLocation;
    }

    @Override
    public class_806 overrides(final class_7775 modelBaker, final class_793 model) {
        return getItemOverrides(modelBaker, model);
    }
}
