package com.grim3212.assorted.lib.mixin.client.model;

import com.grim3212.assorted.lib.client.model.loader.FabricExtendedBlockModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_4730;
import net.minecraft.class_793;
import net.minecraft.class_801;

@Mixin(class_801.class)
public abstract class ItemModelGeneratorMixin {

    @Inject(method = "generateBlockModel(Ljava/util/function/Function;Lnet/minecraft/client/renderer/block/model/BlockModel;)Lnet/minecraft/client/renderer/block/model/BlockModel;",
            at = @At("HEAD"),
            locals = LocalCapture.CAPTURE_FAILHARD,
            cancellable = true)
    public void onGenerate(Function<class_4730, class_1058> spriteGetter, class_793 model, CallbackInfoReturnable<class_793> cir) {
        if (model instanceof FabricExtendedBlockModel extendedModel) {
            cir.setReturnValue(extendedModel);
        }
    }
}
