package com.grim3212.assorted.lib.mixin.world.entity.player;

import com.grim3212.assorted.lib.events.EntityInteractEvent;
import com.grim3212.assorted.lib.platform.Services;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public class PlayerMixin {

    @Inject(method = "interactOn", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/entity/player/Player;getItemInHand(Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/item/ItemStack;",
            ordinal = 0),
            cancellable = true)
    private void assortedlib_entityInteract(class_1297 entity, class_1268 interactionHand, CallbackInfoReturnable<class_1269> cir) {
        final EntityInteractEvent event = new EntityInteractEvent((class_1657) (Object) this, interactionHand, entity);
        Services.EVENTS.handleEvents(event);

        if (event.getInteractionResult() == class_1269.field_5812) {
            cir.setReturnValue(class_1269.field_5812);
        }
    }
}
