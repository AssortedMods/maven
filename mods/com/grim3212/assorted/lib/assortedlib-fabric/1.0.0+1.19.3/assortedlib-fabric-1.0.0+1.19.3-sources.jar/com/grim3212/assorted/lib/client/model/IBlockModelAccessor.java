package com.grim3212.assorted.lib.client.model;

import com.mojang.datafixers.util.Either;
import net.minecraft.class_2960;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_785;
import net.minecraft.class_793;
import net.minecraft.class_799;
import net.minecraft.class_806;
import net.minecraft.class_809;
import net.minecraft.client.renderer.block.model.*;
import java.util.List;
import java.util.Map;

public interface IBlockModelAccessor {

    List<class_785> elements();

    class_793.class_4751 guiLight();

    boolean usesAmbientOcclusion();

    class_809 transforms();

    List<class_799> overrides();

    String name();

    Map<String, Either<class_4730, String>> textureMap();

    class_793 parent();

    class_2960 parentLocation();

    class_806 overrides(class_7775 modelBaker, class_793 model);
}
