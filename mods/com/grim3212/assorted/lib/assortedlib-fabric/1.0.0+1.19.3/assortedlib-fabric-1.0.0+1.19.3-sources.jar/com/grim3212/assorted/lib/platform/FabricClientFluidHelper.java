package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.core.fluid.FluidInformation;
import com.grim3212.assorted.lib.platform.services.IClientFluidHelper;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.minecraft.class_1058;
import net.minecraft.class_2960;
import net.minecraft.class_3611;

public class FabricClientFluidHelper implements IClientFluidHelper {

    @Override
    public int getFluidColor(FluidInformation fluid) {
        return FluidVariantRendering.getColor(FabricFluidManager.makeVariant(fluid));
    }

    @Override
    public class_1058 getSprite(FluidInformation fluid) {
        return FluidVariantRendering.getSprite(FabricFluidManager.makeVariant(fluid));
    }

    @Override
    public class_2960 getFlowingFluidTexture(final FluidInformation fluidInformation) {
        return FluidVariantRendering.getSprite(FabricFluidManager.makeVariant(fluidInformation)).method_45851().method_45816();
    }

    @Override
    public class_2960 getFlowingFluidTexture(final class_3611 fluid) {
        return getFlowingFluidTexture(new FluidInformation(fluid));
    }

    @Override
    public class_2960 getStillFluidTexture(final FluidInformation fluidInformation) {
        return FluidVariantRendering.getSprite(FabricFluidManager.makeVariant(fluidInformation)).method_45851().method_45816();
    }

    @Override
    public class_2960 getStillFluidTexture(final class_3611 fluid) {
        return getFlowingFluidTexture(new FluidInformation(fluid));
    }
}
