package com.grim3212.assorted.lib.crafting.ingredient;

import com.grim3212.assorted.lib.core.crafting.ingredient.LibFluidIngredient;
import com.grim3212.assorted.lib.platform.Services;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredient;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredientSerializer;
import net.minecraft.class_1792;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import org.jetbrains.annotations.Nullable;

public class FabricFluidIngredient extends LibFluidIngredient implements CustomIngredient {

    public static final com.grim3212.assorted.lib.crafting.ingredient.FabricFluidIngredient.Serializer SERIALIZER = new com.grim3212.assorted.lib.crafting.ingredient.FabricFluidIngredient.Serializer();

    protected FabricFluidIngredient(@Nullable class_6862<class_1792> itemTag, class_6862<class_3611> fluidTag) {
        this(itemTag, fluidTag, Services.FLUIDS.getBucketAmount());
    }

    protected FabricFluidIngredient(@Nullable class_6862<class_1792> itemTag, class_6862<class_3611> fluidTag, long amount) {
        super(itemTag, fluidTag, amount);
    }

    public static FabricFluidIngredient of(@Nullable class_6862<class_1792> itemTag, class_6862<class_3611> fluidTag) {
        return new FabricFluidIngredient(itemTag, fluidTag);
    }

    public static FabricFluidIngredient of(@Nullable class_6862<class_1792> itemTag, class_6862<class_3611> fluidTag, long amount) {
        return new FabricFluidIngredient(itemTag, fluidTag, amount);
    }

    @Override
    public boolean requiresTesting() {
        return false;
    }

    @Override
    public CustomIngredientSerializer<?> getSerializer() {
        return SERIALIZER;
    }

    static class Serializer extends LibFluidIngredient.Serializer<FabricFluidIngredient> implements CustomIngredientSerializer<FabricFluidIngredient> {
        @Override
        protected FabricFluidIngredient create(@Nullable class_6862 itemTag, class_6862 fluidTag, long amount) {
            return new FabricFluidIngredient(itemTag, fluidTag, amount);
        }
    }
}
