package com.grim3212.assorted.lib.client.model.loader;

import com.google.gson.*;
import com.grim3212.assorted.lib.client.model.IBlockModelAccessor;
import com.grim3212.assorted.lib.client.model.loaders.IModelSpecification;
import com.grim3212.assorted.lib.client.model.loaders.IModelSpecificationLoader;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Type;
import net.minecraft.class_793;

public class FabricExtendedBlockModelDeserializer extends class_793.class_795 {

    private final String name;
    private final IModelSpecificationLoader<?> delegate;

    public FabricExtendedBlockModelDeserializer(final String name, final IModelSpecificationLoader<?> delegate) {
        this.name = name;
        this.delegate = delegate;
    }

    @Override
    public class_793 method_3451(JsonElement element, Type targetType, JsonDeserializationContext deserializationContext) throws JsonParseException {
        if (!element.isJsonObject())
            throw new JsonSyntaxException("Model needs to be object");

        final class_793 model = super.method_3451(element, targetType, deserializationContext);
        if (model == null)
            return null;

        JsonObject jsonobject = element.getAsJsonObject();
        final IModelSpecification<?> geometry = deserializeGeometry(deserializationContext, jsonobject);

        if (geometry != null) {
            return new FabricExtendedBlockModel(
                    (IBlockModelAccessor) model,
                    geometry
            );
        }

        return model;
    }

    @Nullable
    public IModelSpecification<?> deserializeGeometry(JsonDeserializationContext deserializationContext, JsonObject object) throws JsonParseException {
        if (!object.has("loader"))
            return null;

        if (!object.get("loader").getAsString().equals(name.toString()))
            return null;

        return delegate.read(deserializationContext, object);
    }
}
