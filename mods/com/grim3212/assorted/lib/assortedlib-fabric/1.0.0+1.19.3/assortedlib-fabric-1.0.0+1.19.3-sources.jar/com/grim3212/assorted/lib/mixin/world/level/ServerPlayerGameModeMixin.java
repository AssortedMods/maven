package com.grim3212.assorted.lib.mixin.world.level;

import com.grim3212.assorted.lib.core.block.IBlockOnPlayerBreak;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_3225.class)
public abstract class ServerPlayerGameModeMixin {

    @Shadow
    protected class_3218 level;
    @Shadow
    protected class_3222 player;

    @Shadow
    protected abstract boolean isCreative();

    @Inject(method = "destroyBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/Block;playerWillDestroy(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/entity/player/Player;)V"), cancellable = true, locals = LocalCapture.CAPTURE_FAILHARD)
    private void onDestroy(class_2338 pos, CallbackInfoReturnable<Boolean> info, class_2680 state, class_2586 blockEntity) {
        if (state.method_26204() instanceof IBlockOnPlayerBreak extraProperties) {
            if (this.isCreative()) {
                this.removeBlock(state, extraProperties, pos, false);
                info.setReturnValue(true);
                return;
            }
            class_1799 itemStack = this.player.method_6047();
            class_1799 itemStack2 = itemStack.method_7972();
            boolean canHarvest = this.player.method_7305(state);
            itemStack.method_7952(this.level, state, pos, this.player);

            boolean removed = this.removeBlock(state, extraProperties, pos, canHarvest);

            if (canHarvest && removed) {
                state.method_26204().method_9556(this.level, this.player, pos, state, blockEntity, itemStack2);
            }

            info.setReturnValue(true);
        }
    }

    private boolean removeBlock(class_2680 state, IBlockOnPlayerBreak extraProperties, class_2338 arg, boolean canHarvest) {
        boolean removed = extraProperties.onDestroyedByPlayer(state, this.level, arg, this.player, canHarvest, this.level.method_8316(arg));
        if (removed) {
            state.method_26204().method_9585(this.level, arg, state);
        }
        return removed;
    }
}
