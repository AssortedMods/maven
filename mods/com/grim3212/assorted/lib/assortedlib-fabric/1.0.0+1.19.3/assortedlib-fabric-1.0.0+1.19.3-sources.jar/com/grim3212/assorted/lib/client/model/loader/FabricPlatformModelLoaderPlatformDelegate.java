package com.grim3212.assorted.lib.client.model.loader;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.grim3212.assorted.lib.client.model.loaders.IModelSpecification;
import com.grim3212.assorted.lib.client.model.loaders.IModelSpecificationLoader;
import com.grim3212.assorted.lib.util.TransformationUtils;
import net.fabricmc.fabric.api.client.model.ModelProviderContext;
import net.fabricmc.fabric.api.client.model.ModelProviderException;
import net.fabricmc.fabric.api.client.model.ModelResourceProvider;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3518;
import net.minecraft.class_4590;
import net.minecraft.class_783;
import net.minecraft.class_785;
import net.minecraft.class_787;
import net.minecraft.class_793;
import net.minecraft.class_799;
import net.minecraft.class_804;
import net.minecraft.class_809;
import net.minecraft.client.renderer.block.model.*;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Optional;

public final class FabricPlatformModelLoaderPlatformDelegate<L extends IModelSpecificationLoader<S>, S extends IModelSpecification<S>> implements ModelResourceProvider {

    private final Gson gson;
    private final String name;

    public FabricPlatformModelLoaderPlatformDelegate(final class_2960 name, final L delegate) {
        this.name = name.toString();
        this.gson = (new GsonBuilder())
                .registerTypeAdapter(class_2960.class, new class_2960.class_2961())
                .registerTypeHierarchyAdapter(class_1100.class, new FabricExtendedBlockModelDeserializer(this.name, delegate))
                .registerTypeHierarchyAdapter(class_793.class, new FabricExtendedBlockModelDeserializer(this.name, delegate))
                .registerTypeAdapter(class_785.class, new class_785.class_786() {
                })
                .registerTypeAdapter(class_783.class, new class_783.class_784() {
                })
                .registerTypeAdapter(class_787.class, new class_787.class_788() {
                })
                .registerTypeAdapter(class_804.class, new class_804.class_805() {
                })
                .registerTypeAdapter(class_809.class, new class_809.class_810() {
                })
                .registerTypeAdapter(class_799.class, new class_799.class_800() {
                })
                .registerTypeAdapter(class_4590.class, new TransformationUtils.Deserializer())
                .create();
    }

    @SuppressWarnings("unchecked")
    @Override
    public @Nullable class_1100 loadModelResource(final class_2960 resourceLocation, final ModelProviderContext modelProviderContext) throws ModelProviderException {
        try {
            final class_2960 target = new class_2960(resourceLocation.method_12836(), "models/" + resourceLocation.method_12832() + ".json");

            final Optional<class_3298> resource = class_310.method_1551().method_1478().method_14486(target);
            if (resource.isEmpty())
                return null;

            final InputStream inputStream = resource.get().method_14482();
            final InputStreamReader streamReader = new InputStreamReader(inputStream);

            final JsonElement specificationData = gson.fromJson(streamReader, JsonElement.class);

            streamReader.close();
            inputStream.close();

            if (!specificationData.isJsonObject())
                return null;

            final JsonObject modelSpecification = specificationData.getAsJsonObject();
            if (!modelSpecification.has("loader")) {
                if (modelSpecification.has("parent")) {
                    // If we have a parent model check if the parent model is of our loader
                    return getParentModel(new class_2960(class_3518.method_15253(modelSpecification, "parent", "")));
                }
                return null;
            }

            if (!modelSpecification.get("loader").getAsString().equals(this.name))
                return null;

            return this.gson.fromJson(modelSpecification, class_1100.class);
        } catch (IOException e) {
            throw new ModelProviderException("Failed to find and read resource", e);
        }
    }

    private @Nullable class_1100 getParentModel(class_2960 parentLocation) throws IOException {
        final class_2960 target = new class_2960(parentLocation.method_12836(), "models/" + parentLocation.method_12832() + ".json");

        final Optional<class_3298> resource = class_310.method_1551().method_1478().method_14486(target);
        if (resource.isEmpty())
            return null;

        final InputStream inputStream = resource.get().method_14482();
        final InputStreamReader streamReader = new InputStreamReader(inputStream);

        final JsonElement specificationData = gson.fromJson(streamReader, JsonElement.class);

        streamReader.close();
        inputStream.close();

        if (!specificationData.isJsonObject())
            return null;

        final JsonObject modelSpecification = specificationData.getAsJsonObject();
        if (!modelSpecification.has("loader"))
            return null;

        if (!modelSpecification.get("loader").getAsString().equals(this.name))
            return null;

        return this.gson.fromJson(modelSpecification, class_1100.class);
    }
}
