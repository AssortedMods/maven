package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.client.events.ClientTickHandler;
import com.grim3212.assorted.lib.client.model.loader.FabricPlatformModelLoaderPlatformDelegate;
import com.grim3212.assorted.lib.client.model.loaders.IModelSpecificationLoader;
import com.grim3212.assorted.lib.client.render.IBEWLR;
import com.grim3212.assorted.lib.client.screen.LibScreenFactory;
import com.grim3212.assorted.lib.mixin.client.AccessorMinecraft;
import com.grim3212.assorted.lib.platform.services.IClientHelper;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.model.ModelLoadingRegistry;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_322;
import net.minecraft.class_324;
import net.minecraft.class_325;
import net.minecraft.class_326;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_3695;
import net.minecraft.class_3917;
import net.minecraft.class_3929;
import net.minecraft.class_3936;
import net.minecraft.class_4002;
import net.minecraft.class_437;
import net.minecraft.class_5272;
import net.minecraft.class_5601;
import net.minecraft.class_5607;
import net.minecraft.class_5614;
import net.minecraft.class_5617;
import net.minecraft.class_6395;
import net.minecraft.class_707;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class FabricClientHelper implements IClientHelper {

    @Override
    public <T extends class_1703, S extends class_437 & class_3936<T>> void registerScreen(Supplier<class_3917<? extends T>> menuType, LibScreenFactory<T, S> factory) {
        class_3929.method_17542(menuType.get(), factory::create);
    }

    @Override
    public void registerAdditionalModel(List<class_2960> modelLocations) {
        ModelLoadingRegistry.INSTANCE.registerModelProvider((manager, out) -> {
            for (class_2960 model : modelLocations) {
                out.accept(model);
            }
        });
    }

    @Override
    public void addReloadListener(class_2960 identifier, class_3302 reloadListener) {
        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new IdentifiableResourceReloadListener() {
            @Override
            public class_2960 getFabricId() {
                return identifier;
            }

            @Override
            public CompletableFuture<Void> method_25931(class_4045 preparationBarrier, class_3300 resourceManager, class_3695 profilerFiller, class_3695 profilerFiller2, Executor executor, Executor executor2) {
                return reloadListener.method_25931(preparationBarrier, resourceManager, profilerFiller, profilerFiller2, executor, executor2);
            }
        });
    }

    @Override
    public void registerBEWLR(final Consumer<IBEWLR> register) {
        register.accept((item, renderer) -> BuiltinItemRendererRegistry.INSTANCE.register(item, renderer::method_3166));
    }

    @Override
    public <E extends class_2586> void registerBlockEntityRenderer(Supplier<? extends class_2591<? extends E>> entityType, class_5614<E> entityRendererFactory) {
        BlockEntityRendererRegistry.register(entityType.get(), entityRendererFactory);
    }

    @Override
    public <E extends class_1297> void registerEntityRenderer(Supplier<? extends class_1299<? extends E>> entityType, class_5617<E> entityRendererFactory) {
        EntityRendererRegistry.register(entityType.get(), entityRendererFactory);
    }

    @Override
    public void registerEntityLayer(class_5601 modelLayerLocation, Supplier<class_5607> layerDefinition) {
        EntityModelLayerRegistry.registerModelLayer(modelLayerLocation, layerDefinition::get);
    }

    @Override
    public void registerBlockColor(class_322 color, Supplier<List<class_2248>> blocks) {
        ColorProviderRegistry.BLOCK.register(color, blocks.get().toArray(new class_2248[0]));
    }

    @Override
    public void registerItemColor(class_326 color, Supplier<List<class_1792>> items) {
        ColorProviderRegistry.ITEM.register(color, items.get().toArray(new class_1792[0]));
    }

    @Override
    public class_324 getBlockColors() {
        return class_310.method_1551().method_1505();
    }

    @Override
    public class_325 getItemColors() {
        return ((AccessorMinecraft) class_310.method_1551()).assortedlib_getItemColors();
    }

    @Override
    public void registerModelLoader(class_2960 name, IModelSpecificationLoader<?> modelLoader) {
        ModelLoadingRegistry.INSTANCE.registerResourceProvider(resourceManager -> new FabricPlatformModelLoaderPlatformDelegate<>(name, modelLoader));
    }

    @Override
    public void registerItemProperty(Supplier<class_1792> item, class_2960 location, class_6395 itemPropertyFunction) {
        class_5272.method_27879(item.get(), location, itemPropertyFunction);
    }

    @Override
    public void registerRenderType(Supplier<class_2248> block, class_1921 renderType) {
        BlockRenderLayerMap.INSTANCE.putBlock(block.get(), renderType);
    }

    @Override
    public void registerKeyMapping(class_304 keyMapping) {
        KeyBindingHelper.registerKeyBinding(keyMapping);
    }

    @Override
    public void registerClientTickStart(ClientTickHandler handler) {
        ClientTickEvents.START_CLIENT_TICK.register(handler::handle);
    }

    @Override
    public void registerClientTickEnd(ClientTickHandler handler) {
        ClientTickEvents.END_CLIENT_TICK.register(handler::handle);
    }

    @Override
    public <T extends class_2394> void registerParticle(Supplier<class_2396<T>> type, Function<class_4002, class_707<T>> factory) {
        ParticleFactoryRegistry.getInstance().register(type.get(), sprites -> factory.apply(sprites));
    }

    @Override
    public class_1657 getClientPlayer() {
        return class_310.method_1551().field_1724;
    }
}
