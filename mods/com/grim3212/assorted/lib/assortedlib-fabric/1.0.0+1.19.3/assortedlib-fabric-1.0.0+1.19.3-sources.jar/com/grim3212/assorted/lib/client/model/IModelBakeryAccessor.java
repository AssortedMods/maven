package com.grim3212.assorted.lib.client.model;

import net.minecraft.class_1088;

/**
 * Fabric specific platform interface which gives access to the model bakery.
 */
public interface IModelBakeryAccessor {

    /**
     * The model bakery.
     *
     * @return The model bakery.
     */
    class_1088 getModelBakery();
}
