package com.grim3212.assorted.lib.mixin.world.item.enchantment;

import com.grim3212.assorted.lib.core.enchantment.LibEnchantment;
import com.grim3212.assorted.lib.core.item.IItemEnchantmentCondition;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1887;

@Mixin(class_1887.class)
public class EnchantmentMixin {

    @Inject(
            method = "canEnchant",
            at = @At(value = "HEAD"),
            cancellable = true
    )
    private void assortedlib_canEnchant(class_1799 itemStack, CallbackInfoReturnable<Boolean> cir) {
        class_1887 enchantment = ((class_1887) (Object) this);
        if (enchantment instanceof LibEnchantment libEnchantment) {
            Optional<Boolean> result = libEnchantment.assortedlib_canApplyAtEnchantingTable(itemStack);
            if (result.isPresent()) {
                cir.setReturnValue(result.get());
                return;
            }
        }
        if (itemStack.method_7909() instanceof IItemEnchantmentCondition extension) {
            Optional<Boolean> result = extension.assortedlib_canApplyAtEnchantingTable(itemStack, enchantment);
            if (result.isPresent()) {
                cir.setReturnValue(result.get());
            }
        }
    }
}
