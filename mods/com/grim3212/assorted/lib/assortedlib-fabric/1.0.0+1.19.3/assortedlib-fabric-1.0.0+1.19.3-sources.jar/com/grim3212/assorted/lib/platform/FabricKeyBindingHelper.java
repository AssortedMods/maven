package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.client.key.IKeyConflictHelper;
import com.grim3212.assorted.lib.client.key.KeyModifier;
import com.grim3212.assorted.lib.platform.services.IKeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_5250;


public class FabricKeyBindingHelper implements IKeyBindingHelper {

    @Override
    public IKeyConflictHelper getGuiKeyConflictContext() {
        return FabricGuiKeyConflictHelper.INSTANCE;
    }

    @Override
    public IKeyConflictHelper getInGameKeyConflictContext() {
        return FabricInGameKeyConflictHelper.INSTANCE;
    }

    @Override
    public class_304 createNew(
            final String translationKey, final IKeyConflictHelper keyConflictContext, final class_3675.class_307 inputType, final int key, final String groupTranslationKey) {
        return new class_304(
                translationKey,
                inputType,
                key,
                groupTranslationKey
        );
    }

    @Override
    public class_304 createNew(
            final String translationKey,
            final IKeyConflictHelper keyConflictContext,
            final KeyModifier keyModifier,
            final class_3675.class_307 inputType,
            final int key,
            final String groupTranslationKey) {
        return new ModifiedKeyMapping(translationKey, inputType, key, groupTranslationKey, keyConflictContext, keyModifier);
    }

    @Override
    public boolean isKeyConflictOfActive(final class_304 keybinding) {
        if (keybinding instanceof ModifiedKeyMapping modifiedKeyMapping) {
            return modifiedKeyMapping.context.isActive();
        }

        return true;
    }

    @Override
    public boolean isKeyModifierActive(final class_304 keybinding) {
        if (keybinding instanceof ModifiedKeyMapping modifiedKeyMapping) {
            return modifiedKeyMapping.isKeyModifierActive();
        }

        return true;
    }

    private static final class FabricGuiKeyConflictHelper implements IKeyConflictHelper {

        private static final FabricGuiKeyConflictHelper INSTANCE = new FabricGuiKeyConflictHelper();

        private FabricGuiKeyConflictHelper() {
        }

        @Override
        public boolean isActive() {
            return class_310.method_1551().field_1755 != null;
        }

        @Override
        public boolean conflicts(IKeyConflictHelper other) {
            return this == other;
        }
    }

    private static final class FabricInGameKeyConflictHelper implements IKeyConflictHelper {

        private static final FabricInGameKeyConflictHelper INSTANCE = new FabricInGameKeyConflictHelper();

        private FabricInGameKeyConflictHelper() {
        }

        @Override
        public boolean isActive() {
            return !FabricGuiKeyConflictHelper.INSTANCE.isActive();
        }

        @Override
        public boolean conflicts(IKeyConflictHelper other) {
            return this == other;
        }
    }

    private static class ModifiedKeyMapping extends class_304 {
        private final IKeyConflictHelper context;
        private final KeyModifier keyModifier;

        public ModifiedKeyMapping(
                final String translationKey,
                final class_3675.class_307 inputType,
                final int key,
                final String groupTranslationKey,
                final IKeyConflictHelper context,
                final KeyModifier keyModifier) {
            super(translationKey,
                    inputType,
                    key,
                    groupTranslationKey);
            this.context = context;
            this.keyModifier = keyModifier;
        }

        @Override
        public boolean method_1434() {
            return super.method_1434() && isKeyModifierActive();
        }

        private boolean isKeyModifierActive() {
            return switch (keyModifier) {
                case CONTROL -> class_437.method_25441();
                case SHIFT -> class_437.method_25442();
                case ALT -> class_437.method_25443();
            };
        }

        @Override
        public class_2561 method_16007() {
            return getKeyModifierMessage().method_10852(super.method_16007());
        }

        private class_5250 getKeyModifierMessage() {
            return switch (keyModifier) {
                case CONTROL -> class_2561.method_43470("CTRL + ");
                case SHIFT -> class_2561.method_43470("SHIFT + ");
                case ALT -> class_2561.method_43470("ALT + ");
            };
        }
    }
}
