package com.grim3212.assorted.lib.data;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_6957;
import net.minecraft.class_7225;
import net.minecraft.class_7784;

public class FabricBiomeTagProvider extends class_6957 {

    private final LibBiomeTagProvider commonBiomes;

    public FabricBiomeTagProvider(class_7784 output, CompletableFuture<class_7225.class_7874> lookup, LibBiomeTagProvider commonBiomes) {
        super(output, lookup);
        this.commonBiomes = commonBiomes;
    }

    @Override
    protected void method_10514(class_7225.class_7874 lookup) {
        this.commonBiomes.addCommonTags(this::method_10512);
    }
}
