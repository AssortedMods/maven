package com.grim3212.assorted.lib.data;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2248;
import net.minecraft.class_2471;
import net.minecraft.class_2474;
import net.minecraft.class_7225;
import net.minecraft.class_7784;

public class FabricItemTagProvider extends class_2471 {

    private final LibItemTagProvider commonItems;

    public FabricItemTagProvider(class_7784 output, CompletableFuture<class_7225.class_7874> lookup, class_2474<class_2248> blockTagsProvider, LibItemTagProvider commonItems) {
        super(output, lookup, blockTagsProvider);
        this.commonItems = commonItems;
    }

    @Override
    protected void method_10514(class_7225.class_7874 lookup) {
        this.commonItems.addCommonTags(this::method_46827, this::method_46218);
    }
}
