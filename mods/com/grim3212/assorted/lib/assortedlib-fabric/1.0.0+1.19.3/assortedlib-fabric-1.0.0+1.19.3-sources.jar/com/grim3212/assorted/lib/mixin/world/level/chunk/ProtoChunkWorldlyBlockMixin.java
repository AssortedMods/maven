package com.grim3212.assorted.lib.mixin.world.level.chunk;

import com.grim3212.assorted.lib.core.block.IBlockExtraProperties;
import com.grim3212.assorted.lib.core.block.IBlockLightEmission;
import net.minecraft.class_1922;
import net.minecraft.class_1923;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_2826;
import net.minecraft.class_2839;
import net.minecraft.class_2843;
import net.minecraft.class_3568;
import net.minecraft.class_5539;
import net.minecraft.class_6749;
import net.minecraft.world.level.chunk.*;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import javax.annotation.Nullable;
import java.util.List;

@Mixin(class_2839.class)
public abstract class ProtoChunkWorldlyBlockMixin extends class_2791 implements class_1922 {

    @Shadow
    @Final
    private List<class_2338> lights;
    @Shadow
    private volatile class_2806 status;
    @Shadow
    @Nullable
    private volatile class_3568 lightEngine;

    public ProtoChunkWorldlyBlockMixin(final class_1923 chunkPos, final class_2843 upgradeData, final class_5539 levelHeightAccessor, final class_2378<class_1959> registry, final long l, @Nullable final class_2826[] levelChunkSections, @Nullable final class_6749 blendingData) {
        super(chunkPos, upgradeData, levelHeightAccessor, registry, l, levelChunkSections, blendingData);
    }

    @Inject(
            method = "setBlockState",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;getLightEmission()I",
                    ordinal = 0
            )
    )
    public void assortedlib_onSetBlockStateAddCustomLights(final class_2338 pos, final class_2680 state, final boolean isMoving, final CallbackInfoReturnable<class_2680> cir) {
        int i = pos.method_10263();
        int j = pos.method_10264();
        int k = pos.method_10260();

        if (state.method_26204() instanceof IBlockLightEmission extraProperties && extraProperties.getLightEmission(state, this, pos) > 0) {
            this.lights.add(new class_2338((i & 15) + this.method_12004().method_8326(), j, (k & 15) + this.method_12004().method_8328()));
        }
    }

    @ModifyVariable(
            method = "setBlockState",
            at = @At(
                    value = "STORE"
            ),
            index = 9)
    public class_2680 assortedlib_onSetBlockStateDoLightEngineUpdate(final class_2680 blockState, class_2338 pos, class_2680 state, boolean isMoving) {
        if (state.method_26213() == blockState.method_26213() && (state.method_26204() instanceof IBlockExtraProperties || blockState.method_26204() instanceof IBlockExtraProperties)) {
            int newBlockEmissions = state.method_26213();
            if (state.method_26204() instanceof IBlockLightEmission newExtraProperties) {
                newBlockEmissions = newExtraProperties.getLightEmission(state, this, pos);
            }

            int oldBlockEmissions = blockState.method_26213();
            if (blockState.method_26204() instanceof IBlockLightEmission oldExtraProperties) {
                oldBlockEmissions = oldExtraProperties.getLightEmission(state, this, pos);
            }

            if (this.status.method_12165(class_2806.field_12795) && state != blockState && (state.method_26193(this, pos) != blockState.method_26193(this, pos) || newBlockEmissions != oldBlockEmissions || state.method_26211() || blockState.method_26211())) {
                if (this.lightEngine != null) {
                    this.lightEngine.method_15513(pos);
                }
            }
        }

        return blockState;
    }
}
