package com.grim3212.assorted.lib.testing;

import com.grim3212.assorted.lib.core.block.IBlockOnPlayerBreak;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3610;

public class BlockBreakCancelTest extends class_2248 implements IBlockOnPlayerBreak {
    public BlockBreakCancelTest(class_2251 properties) {
        super(properties);
    }

    @Override
    public boolean onDestroyedByPlayer(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, boolean willHarvest, class_3610 fluid) {

        if (player.method_7337()) {
            return false;
        }

        this.method_9576(level, pos, state, player);
        return level.method_8652(pos, fluid.method_15759(), level.field_9236 ? class_2248.field_31022 : class_2248.field_31036);
    }
}
