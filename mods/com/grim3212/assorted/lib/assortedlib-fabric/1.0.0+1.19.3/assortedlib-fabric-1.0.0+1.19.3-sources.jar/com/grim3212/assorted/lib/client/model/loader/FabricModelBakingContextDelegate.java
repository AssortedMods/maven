package com.grim3212.assorted.lib.client.model.loader;

import com.grim3212.assorted.lib.client.model.IBlockModelAccessor;
import com.grim3212.assorted.lib.client.model.IModelBakeryAccessor;
import com.grim3212.assorted.lib.client.model.loaders.context.IModelBakingContext;
import java.util.Optional;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_806;
import net.minecraft.class_809;

public class FabricModelBakingContextDelegate implements IModelBakingContext {

    private final FabricExtendedBlockModel source;
    private final IBlockModelAccessor sourceAccessor;

    public FabricModelBakingContextDelegate(final FabricExtendedBlockModel source) {
        this.source = source;
        this.sourceAccessor = (IBlockModelAccessor) source;
    }

    @Override
    public class_1100 getUnbakedModel(final class_2960 unbakedModel) {
        final IModelBakeryAccessor modelBakeryAccessor = (IModelBakeryAccessor) class_310.method_1551().method_1554();
        return modelBakeryAccessor.getModelBakery().method_4726(unbakedModel);
    }

    @Override
    public Optional<class_4730> getMaterial(final String name) {
        if (source.method_3432(name)) {
            return Optional.of(source.method_24077(name));
        }

        return Optional.empty();
    }

    @Override
    public boolean isGui3d() {
        return sourceAccessor.guiLight().method_24299();
    }

    @Override
    public boolean useBlockLight() {
        return sourceAccessor.guiLight().method_24299();
    }

    @Override
    public boolean useAmbientOcclusion() {
        return sourceAccessor.usesAmbientOcclusion();
    }

    @Override
    public class_809 getTransforms() {
        return sourceAccessor.transforms();
    }

    @Override
    public class_806 getItemOverrides(class_7775 baker) {
        return sourceAccessor.overrides(baker, source);
    }
}
