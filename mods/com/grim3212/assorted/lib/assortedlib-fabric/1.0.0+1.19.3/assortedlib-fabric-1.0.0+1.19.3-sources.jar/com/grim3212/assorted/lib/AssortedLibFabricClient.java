package com.grim3212.assorted.lib;

import com.grim3212.assorted.lib.core.block.IBlockCloneStack;
import com.grim3212.assorted.lib.platform.FabricNetworkHelper;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.event.client.player.ClientPickBlockGatherCallback;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public class AssortedLibFabricClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            FabricNetworkHelper.initializeClientHandlers();
        });

        ClientPickBlockGatherCallback.EVENT.register((player, result) -> {
            if (result instanceof class_3965 blockHitResult
                    && class_310.method_1551().field_1687 != null
                    && class_310.method_1551().field_1687.method_8320(blockHitResult.method_17777()).method_26204() instanceof IBlockCloneStack extraProperties) {
                return extraProperties.getCloneItemStack(
                        class_310.method_1551().field_1687.method_8320(blockHitResult.method_17777()),
                        result,
                        class_310.method_1551().field_1687,
                        ((class_3965) result).method_17777(),
                        player
                );
            }

            return class_1799.field_8037;
        });
    }
}
