package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.platform.services.IWorldGenHelper;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class FabricWorldGenHelper implements IWorldGenHelper {
    @Override
    public void addFeatureToBiomes(BiomePredicate biomePredicate, class_2893.class_2895 step, class_2960 placedFeatureIdentifier) {
        BiomeModifications.addFeature(it -> biomePredicate.test(it.getBiomeKey().method_29177(), it.getBiomeRegistryEntry()), step, class_5321.method_29179(class_7924.field_41245, placedFeatureIdentifier));
    }
}
