package com.grim3212.assorted.lib.mixin.world.level.chunk.storage;

import com.grim3212.assorted.lib.core.block.IBlockLightEmission;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2839;
import net.minecraft.class_2852;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_2852.class)
public abstract class ChunkSerializerWorldlyBlockMixin {

    @Unique
    private static final ThreadLocal<class_2839> chunkAccessHolder = new ThreadLocal<>();
    @Unique
    private static final ThreadLocal<class_2338> blockPosHolder = new ThreadLocal<>();


    @ModifyArg(
            method = "read",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/chunk/ChunkAccess;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;"
            ),
            index = 0
    )
    private static class_2338 assortedlib_redirectGetChunkAccessBlockPos(class_2338 blockPos) {
        final class_2680 blockState = chunkAccessHolder.get().method_8320(blockPos);
        if (blockState.method_26204() instanceof IBlockLightEmission extraProperties) {
            if (extraProperties.getLightEmission(blockState, chunkAccessHolder.get(), blockPosHolder.get()) != 0) {
                chunkAccessHolder.get().method_12315(blockPos);
            }
        }

        return blockPos;
    }

    @ModifyVariable(
            method = "read",
            at = @At(
                    value = "STORE"
            ),
            ordinal = 0
    )
    private static class_2839 assortedlib_redirectGetChunkAccessChunkAccess(final class_2839 value) {
        chunkAccessHolder.set(value);
        return value;
    }
}
