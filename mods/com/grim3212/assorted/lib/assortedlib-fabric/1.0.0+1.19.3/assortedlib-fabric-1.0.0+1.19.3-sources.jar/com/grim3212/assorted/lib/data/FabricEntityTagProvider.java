package com.grim3212.assorted.lib.data;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2467;
import net.minecraft.class_7225;
import net.minecraft.class_7784;

public class FabricEntityTagProvider extends class_2467 {

    private final LibEntityTagProvider commonEntities;

    public FabricEntityTagProvider(class_7784 output, CompletableFuture<class_7225.class_7874> lookup, LibEntityTagProvider commonEntities) {
        super(output, lookup);
        this.commonEntities = commonEntities;
    }

    @Override
    protected void method_10514(class_7225.class_7874 lookup) {
        this.commonEntities.addCommonTags(this::method_46827);
    }
}
