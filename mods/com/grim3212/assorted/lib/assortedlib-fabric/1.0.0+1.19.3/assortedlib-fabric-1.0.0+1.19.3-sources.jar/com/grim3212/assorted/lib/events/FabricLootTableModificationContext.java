package com.grim3212.assorted.lib.events;

import net.minecraft.class_52;
import net.minecraft.class_55;

public class FabricLootTableModificationContext implements LootTableModifyEvent.LootTableModificationContext {
    private final class_52.class_53 tableBuilder;

    public FabricLootTableModificationContext(class_52.class_53 tableBuilder) {
        this.tableBuilder = tableBuilder;
    }

    @Override
    public void addPool(class_55 pool) {
        tableBuilder.pool(pool);
    }

    @Override
    public void addPool(class_55.class_56 pool) {
        tableBuilder.method_336(pool);
    }
}
