package com.grim3212.assorted.lib.mixin.world.entity;

import com.grim3212.assorted.lib.core.block.IBlockExtraProperties;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1303;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1303.class)
public abstract class ExperienceOrbWorldlyBlockMixin extends class_1297 {
    public ExperienceOrbWorldlyBlockMixin(final class_1299<?> entityType, final class_1937 level) {
        super(entityType, level);
    }

    @ModifyVariable(
            method = "tick",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/level/block/Block;getFriction()F"
            )
    )
    private float assortedlib_injectGetFrictionAdaptor(final float current) {
        final class_2338 pPos = new class_2338(this.method_23317(), this.method_23318() - 1.0D, this.method_23321());
        final class_2680 blockState = this.field_6002.method_8320(pPos);

        if (blockState.method_26204() instanceof IBlockExtraProperties extraProperties) {
            return extraProperties.getFriction(blockState, this.field_6002, pPos, this) * 0.98f;
        }
        return current;
    }
}
