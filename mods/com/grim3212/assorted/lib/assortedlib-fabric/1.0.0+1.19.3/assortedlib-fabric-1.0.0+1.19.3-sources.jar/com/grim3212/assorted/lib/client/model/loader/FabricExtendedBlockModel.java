package com.grim3212.assorted.lib.client.model.loader;

import com.grim3212.assorted.lib.client.model.IBlockModelAccessor;
import com.grim3212.assorted.lib.client.model.loaders.IModelSpecification;
import java.util.Collections;
import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_793;

public class FabricExtendedBlockModel extends class_793 {
    private final IModelSpecification<?> specification;

    public FabricExtendedBlockModel(final IBlockModelAccessor blockModel, final IModelSpecification<?> specification) {
        super(blockModel.parentLocation(), Collections.emptyList(), blockModel.textureMap(), blockModel.usesAmbientOcclusion(), blockModel.guiLight(), blockModel.transforms(), blockModel.overrides());
        this.specification = specification;
    }

    @Override
    public class_1087 method_4753(class_7775 modelBaker, Function<class_4730, class_1058> function, class_3665 modelState, class_2960 resourceLocation) {
        final FabricModelBakingContextDelegate context = new FabricModelBakingContextDelegate(this);

        final class_1087 bakedModel = specification.bake(context, modelBaker, function, modelState, resourceLocation);
        return new FabricBakedModelDelegate(bakedModel);
    }

    @Override
    public class_1087 method_3446(class_7775 modelBaker, class_793 blockModel, Function<class_4730, class_1058> function, class_3665 modelState, class_2960 resourceLocation, boolean bl) {
        final FabricModelBakingContextDelegate context = new FabricModelBakingContextDelegate(this);

        final class_1087 bakedModel = specification.bake(context, modelBaker, function, modelState, resourceLocation);
        return new FabricBakedModelDelegate(bakedModel);
    }
}
