package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.core.fluid.FluidInformation;
import com.grim3212.assorted.lib.core.fluid.IFluidVariantHandler;
import com.grim3212.assorted.lib.fluid.FabricFluidVariantHandlerDelegate;
import com.grim3212.assorted.lib.platform.services.IFluidManager;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import java.util.Optional;

@SuppressWarnings("removal")
public class FabricFluidManager implements IFluidManager {
    @Override
    public Optional<FluidInformation> get(final class_1799 stack) {
        final Storage<FluidVariant> target = FluidStorage.ITEM.find(stack, ContainerItemContext.withInitial(stack));
        if (target == null)
            return Optional.empty();

        if (!target.iterator().hasNext())
            return Optional.empty();

        final StorageView<FluidVariant> view = target.iterator().next();

        return Optional.of(
                new FluidInformation(
                        view.getResource().getFluid(),
                        view.getAmount(),
                        view.getResource().copyNbt()
                )
        );
    }

    @Override
    public class_1799 extractFrom(final class_1799 stack, final long amount) {
        try (final Transaction context = Transaction.openOuter()) {
            final Optional<FluidInformation> contained = get(stack);

            return contained.map(fluid -> {
                final FluidVariant variant = makeVariant(fluid);
                final ContainerItemContext containerContext = ContainerItemContext.withInitial(stack);

                FluidStorage.ITEM.find(stack, containerContext).extract(variant, amount, context);

                final StorageView<ItemVariant> itemVariant = containerContext.getMainSlot().iterator().next();
                return itemVariant.getResource().toStack((int) itemVariant.getAmount());
            }).orElse(class_1799.field_8037);
        }
    }

    @Override
    @SuppressWarnings("removal")
    public class_1799 insertInto(final class_1799 stack, final FluidInformation fluidInformation) {
        try (final Transaction context = Transaction.openOuter()) {
            final Optional<FluidInformation> contained = get(stack);

            return contained.map(fluid -> {
                final FluidVariant variant = makeVariant(fluid);
                final ContainerItemContext containerContext = ContainerItemContext.withInitial(stack);

                FluidStorage.ITEM.find(stack, containerContext).insert(variant, fluidInformation.amount(), context);

                final StorageView<ItemVariant> itemVariant = containerContext.getMainSlot().iterator().next();
                return itemVariant.getResource().toStack((int) itemVariant.getAmount());
            }).orElse(class_1799.field_8037);
        }
    }

    @Override
    public long simulateInsert(final class_1799 stack, final FluidInformation fluidInformation) {
        final FluidVariant variant = makeVariant(fluidInformation);
        final ContainerItemContext containerContext = ContainerItemContext.withInitial(stack);
        return FluidStorage.ITEM.find(stack, containerContext).simulateInsert(variant, fluidInformation.amount(), null);
    }

    @Override
    public long simulateExtract(final class_1799 stack, final long amount) {
        final Optional<FluidInformation> contained = get(stack);

        return contained.map(fluid -> {
            final FluidVariant variant = makeVariant(fluid);
            final ContainerItemContext containerContext = ContainerItemContext.withInitial(stack);

            return FluidStorage.ITEM.find(stack, containerContext).simulateExtract(variant, amount, null);
        }).orElse(0L);
    }

    @Override
    public class_2561 getDisplayName(final class_3611 fluid) {
        return fluid.method_15785().method_15759().method_26204().method_9518();
    }

    @Override
    public String fluidStackTag() {
        return "Fluid";
    }

    @Override
    public Optional<IFluidVariantHandler> getVariantHandlerFor(class_3611 fluid) {
        return Optional.of(new FabricFluidVariantHandlerDelegate(FluidVariantAttributes.getHandlerOrDefault(fluid)));
    }

    public static FluidVariant makeVariant(final FluidInformation fluid) {
        if (!fluid.fluid().method_15793(fluid.fluid().method_15785()) && fluid.fluid() != class_3612.field_15906) {
            //We have a flowing fluid.
            //Let's make a none flowing variant of it.
            return makeVariant(fluid.withSource());
        }

        if (fluid.data() == null)
            return FluidVariant.of(fluid.fluid());

        return FluidVariant.of(fluid.fluid(), fluid.data());
    }

    public static FluidInformation makeInformation(final FluidVariant fluid, final long count) {
        if (!fluid.getFluid().method_15793(fluid.getFluid().method_15785()) && fluid.getFluid() != class_3612.field_15906) {
            //We have a flowing fluid.
            //Let's make a none flowing variant of it.
            if (fluid.getFluid() instanceof class_3609 flowingFluid) {
                return makeInformation(FluidVariant.of(flowingFluid.method_15751(), fluid.copyNbt()), count);
            }
        }

        if (fluid.copyNbt() == null)
            return new FluidInformation(fluid.getFluid(), count);

        return new FluidInformation(fluid.getFluid(), count, fluid.copyNbt());
    }

    public static FluidInformation makeInformation(final FluidVariant fluid) {
        return makeInformation(fluid, 1);
    }

    @Override
    public long getBucketAmount() {
        return FluidConstants.BUCKET;
    }
}
