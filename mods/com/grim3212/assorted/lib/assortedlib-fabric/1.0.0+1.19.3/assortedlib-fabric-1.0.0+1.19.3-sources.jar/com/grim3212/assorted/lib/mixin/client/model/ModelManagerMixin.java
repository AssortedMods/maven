package com.grim3212.assorted.lib.mixin.client.model;

import com.grim3212.assorted.lib.client.model.IModelBakeryAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import net.minecraft.class_1088;
import net.minecraft.class_1092;
import net.minecraft.class_2960;
import net.minecraft.class_3695;
import net.minecraft.class_4724;

@Mixin(class_1092.class)
public abstract class ModelManagerMixin implements IModelBakeryAccessor {

    @Unique
    private class_1088 currentBakery = null;

    @Inject(
            method = "loadModels(Lnet/minecraft/util/profiling/ProfilerFiller;Ljava/util/Map;Lnet/minecraft/client/resources/model/ModelBakery;)Lnet/minecraft/client/resources/model/ModelManager$ReloadState;",
            at = @At(
                    value = "HEAD"
            )
    )
    public void onApply(class_3695 profilerFiller, Map<class_2960, class_4724.class_7774> map, class_1088 modelBakery, CallbackInfoReturnable<class_1092.class_7779> cir) {
        this.currentBakery = modelBakery;
    }

    @Override
    public class_1088 getModelBakery() {
        if (currentBakery == null) {
            throw new IllegalStateException("ModelBakery is not available yet");
        }

        return currentBakery;
    }
}
