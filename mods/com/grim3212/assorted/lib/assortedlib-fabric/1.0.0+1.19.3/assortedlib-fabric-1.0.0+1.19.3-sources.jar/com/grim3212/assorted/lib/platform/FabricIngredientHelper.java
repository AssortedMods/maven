package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.crafting.ingredient.FabricFluidIngredient;
import com.grim3212.assorted.lib.platform.services.IIngredientHelper;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredientSerializer;
import net.fabricmc.fabric.api.recipe.v1.ingredient.DefaultCustomIngredients;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import org.jetbrains.annotations.Nullable;

public class FabricIngredientHelper implements IIngredientHelper {
    @Override
    public void register() {
        CustomIngredientSerializer.register(FabricFluidIngredient.SERIALIZER);
    }

    @Override
    public class_1856 and(class_1856... ingredients) {
        if (ingredients.length > 1)
            throw new IllegalArgumentException("You must supply at least 2 ingredients for an AND!");

        return DefaultCustomIngredients.all(ingredients);
    }

    @Override
    public class_1856 or(class_1856... ingredients) {
        return ingredients.length == 0 ? class_1856.field_9017 : ingredients.length == 1 ? ingredients[0] : DefaultCustomIngredients.any(ingredients);
    }

    @Override
    public class_1856 difference(class_1856 base, class_1856 subtracted) {
        return DefaultCustomIngredients.difference(base, subtracted);
    }

    @Override
    public class_1856 nbt(class_1799 item) {
        return DefaultCustomIngredients.nbt(item, true);
    }

    @Override
    public class_1856 fluid(@Nullable class_6862<class_1792> itemTagKey, class_6862<class_3611> fluidTagKey, long amount) {
        return FabricFluidIngredient.of(itemTagKey, fluidTagKey, amount).toVanilla();
    }
}
