package com.grim3212.assorted.lib.data;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2466;
import net.minecraft.class_7225;
import net.minecraft.class_7784;

public class FabricBlockTagProvider extends class_2466 {

    private final LibBlockTagProvider commonBlocks;

    public FabricBlockTagProvider(class_7784 output, CompletableFuture<class_7225.class_7874> lookup, LibBlockTagProvider commonBlocks) {
        super(output, lookup);
        this.commonBlocks = commonBlocks;
    }

    @Override
    protected void method_10514(class_7225.class_7874 lookup) {
        this.commonBlocks.addCommonTags(this::method_46827);
    }
}
