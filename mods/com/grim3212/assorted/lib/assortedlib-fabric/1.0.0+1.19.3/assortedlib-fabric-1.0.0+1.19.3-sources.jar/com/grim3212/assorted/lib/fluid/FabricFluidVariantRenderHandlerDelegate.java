package com.grim3212.assorted.lib.fluid;

import com.grim3212.assorted.lib.core.fluid.IFluidVariantHandler;
import com.grim3212.assorted.lib.platform.FabricFluidManager;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRenderHandler;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import org.jetbrains.annotations.Nullable;

public class FabricFluidVariantRenderHandlerDelegate implements FluidVariantRenderHandler {
    private final IFluidVariantHandler delegate;

    public FabricFluidVariantRenderHandlerDelegate(final IFluidVariantHandler delegate) {
        this.delegate = delegate;
    }

    @Override
    public @Nullable class_1058[] getSprites(final FluidVariant fluidVariant) {
        return new class_1058[]{
                class_310.method_1551().method_1549(class_1059.field_5275).apply(delegate.getStillTexture(FabricFluidManager.makeInformation(fluidVariant)).orElseThrow()),
                delegate.getFlowingTexture(FabricFluidManager.makeInformation(fluidVariant)).map(texture -> class_310.method_1551().method_1549(class_1059.field_5275).apply(texture)).orElse(null)
        };
    }

    @Override
    public int getColor(final FluidVariant fluidVariant, @Nullable final class_1920 view, @Nullable final class_2338 pos) {
        return delegate.getTintColor(FabricFluidManager.makeInformation(fluidVariant));
    }

    public IFluidVariantHandler getDelegate() {
        return delegate;
    }
}
