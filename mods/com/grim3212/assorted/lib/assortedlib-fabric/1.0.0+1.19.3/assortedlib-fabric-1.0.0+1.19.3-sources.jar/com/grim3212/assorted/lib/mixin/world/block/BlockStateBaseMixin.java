package com.grim3212.assorted.lib.mixin.world.block;

import com.grim3212.assorted.lib.core.block.IBlockMapColor;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3620;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2248.BlockStateBase.class)
public abstract class BlockStateBaseMixin {

    @Shadow
    public abstract class_2248 getBlock();

    @Shadow
    public abstract class_2680 asState();

    @Shadow
    public class_3620 materialColor;


    @Inject(method = "getMapColor", at = @At("HEAD"), cancellable = true)
    public void assortedlib_getMapColor(class_1922 level, class_2338 pos, CallbackInfoReturnable<class_3620> cir) {
        if (getBlock() instanceof IBlockMapColor mapColor) {
            cir.setReturnValue(mapColor.getMapColor(asState(), level, pos, materialColor));
        }
    }

}
