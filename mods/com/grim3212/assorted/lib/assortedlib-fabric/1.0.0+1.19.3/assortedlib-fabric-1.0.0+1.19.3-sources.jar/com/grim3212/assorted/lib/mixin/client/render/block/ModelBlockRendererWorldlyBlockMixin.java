package com.grim3212.assorted.lib.mixin.client.render.block;

import com.grim3212.assorted.lib.core.block.IBlockLightEmission;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import net.minecraft.class_778;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_778.class)
public abstract class ModelBlockRendererWorldlyBlockMixin {
    @Shadow
    public abstract void tesselateWithAO(final class_1920 p_234391_, final class_1087 p_234392_, final class_2680 p_234393_, final class_2338 p_234394_, final class_4587 p_234395_, final class_4588 p_234396_, final boolean p_234397_, final class_5819 p_234398_, final long p_234399_, final int p_234400_);

    @Inject(
            method = "tesselateBlock",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/block/ModelBlockRenderer;tesselateWithoutAO(Lnet/minecraft/world/level/BlockAndTintGetter;Lnet/minecraft/client/resources/model/BakedModel;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;ZLnet/minecraft/util/RandomSource;JI)V"
            ),
            cancellable = true)
    private void assortedlib_handleWorldlyBlocksWhichDoNotEmitDefaultLightForAO(final class_1920 blockAndTintGetter, final class_1087 bakedModel, final class_2680 blockState, final class_2338 blockPos, final class_4587 poseStack, final class_4588 vertexConsumer, final boolean bl, final class_5819 randomSource, final long l, final int i, final CallbackInfo ci) {
        if (blockState.method_26204() instanceof IBlockLightEmission extraProperties) {
            boolean usesAmbientOcclusion = class_310.method_1588() && extraProperties.getLightEmission(blockState, blockAndTintGetter, blockPos) == 0 && bakedModel.method_4708();
            if (usesAmbientOcclusion) {
                this.tesselateWithAO(blockAndTintGetter, bakedModel, blockState, blockPos, poseStack, vertexConsumer, bl, randomSource, l, i);
                ci.cancel();
            }
        }
    }
}
