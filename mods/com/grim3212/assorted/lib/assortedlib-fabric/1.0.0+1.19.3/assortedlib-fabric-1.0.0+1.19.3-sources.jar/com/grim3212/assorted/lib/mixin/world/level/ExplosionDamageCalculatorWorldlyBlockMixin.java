package com.grim3212.assorted.lib.mixin.world.level;

import com.grim3212.assorted.lib.core.block.IBlockExtraProperties;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_5362;

@Mixin(class_5362.class)
public abstract class ExplosionDamageCalculatorWorldlyBlockMixin {

    @Inject(
            method = "getBlockExplosionResistance",
            at = @At(
                    value = "HEAD"
            ),
            cancellable = true
    )
    public void assortedlib_handleExplosionResistanceOnWorldlyBlocks(final class_1927 explosion, final class_1922 reader, final class_2338 pos, final class_2680 state, final class_3610 fluid, final CallbackInfoReturnable<Optional<Float>> cir) {
        if (state.method_26204() instanceof IBlockExtraProperties extraProperties) {
            cir.setReturnValue(state.method_26215() && fluid.method_15769() ? Optional.empty() : Optional.of(Math.max(extraProperties.getExplosionResistance(state, reader, pos, explosion), fluid.method_15760())));
        }
    }
}
