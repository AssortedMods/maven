package com.grim3212.assorted.lib.mixin.world.level.chunk;

import com.grim3212.assorted.lib.core.block.IBlockLightEmission;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2843;
import net.minecraft.class_5539;
import net.minecraft.class_6749;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_2818.class, priority = Integer.MIN_VALUE)
public abstract class LevelChunkWorldlyBlockMixin extends class_2791 {

    public LevelChunkWorldlyBlockMixin(
            final class_1923 chunkPos,
            final class_2843 upgradeData,
            final class_5539 levelHeightAccessor,
            final class_2378<class_1959> registry,
            final long l,
            @Nullable final class_2826[] levelChunkSections,
            @Nullable final class_6749 blendingData) {
        super(chunkPos, upgradeData, levelHeightAccessor, registry, l, levelChunkSections, blendingData);
    }

    @Shadow
    public abstract class_2680 method_8320(final @NotNull class_2338 param0);

    @Shadow
    public abstract class_1937 getLevel();

    @Inject(method = "method_12217", at = @At(value = "HEAD"), cancellable = true)
    public void assortedlib_getLightsInject(final class_2338 blockPos, final CallbackInfoReturnable<Boolean> cir) {
        final class_2680 blockState = method_8320(blockPos);
        if (blockState.method_26204() instanceof IBlockLightEmission extraProperties) {
            cir.setReturnValue(extraProperties.getLightEmission(blockState, getLevel(), blockPos) != 0);
        }
    }


}
