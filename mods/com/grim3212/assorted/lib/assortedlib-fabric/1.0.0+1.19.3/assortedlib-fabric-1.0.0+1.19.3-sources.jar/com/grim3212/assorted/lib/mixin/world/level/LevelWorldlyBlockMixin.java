package com.grim3212.assorted.lib.mixin.world.level;

import com.grim3212.assorted.lib.core.block.IBlockExtraProperties;
import com.grim3212.assorted.lib.core.block.IBlockLightEmission;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1937.class)
public abstract class LevelWorldlyBlockMixin implements class_1936, AutoCloseable {

    @Unique
    private class_2680 previousState = null;
    @Unique
    private int oldLight = 0;

    private class_1937 getInternalMixinTarget() {
        return (class_1937) (Object) this;
    }

    @Shadow
    public abstract int getDirectSignalTo(final class_2338 param0);

    @Shadow
    public abstract class_2680 method_8320(final class_2338 pPos);

    @Inject(
            method = "getSignal",
            at = @At("HEAD"),
            cancellable = true
    )
    public void assortedlib_checkForWorldlySignalBlock(class_2338 blockPos, class_2350 direction, CallbackInfoReturnable<Integer> cir) {
        final class_2680 blockState = getInternalMixinTarget().method_8320(blockPos);
        if (blockState.method_26204() instanceof IBlockExtraProperties extraProperties) {
            final boolean shouldCheck = extraProperties.shouldCheckWeakPower(blockState, getInternalMixinTarget(), blockPos, direction);
            final int signal = blockState.method_26195(this, blockPos, direction);
            cir.setReturnValue(shouldCheck ? Math.max(signal, this.getDirectSignalTo(blockPos)) : signal);
        }
    }

    @Inject(
            method = "setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;II)Z",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/chunk/LevelChunk;setBlockState(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Z)Lnet/minecraft/world/level/block/state/BlockState;",
                    ordinal = 0,
                    shift = At.Shift.BEFORE
            )
    )
    public void assortedlib_onSetBlockStateCapturePreviousState(final class_2338 pos, final class_2680 state, final int flags, final int recursionLeft, final CallbackInfoReturnable<Boolean> cir) {
        this.previousState = this.method_8320(pos);
        if (previousState.method_26204() instanceof IBlockLightEmission extraProperties) {
            oldLight = extraProperties.getLightEmission(previousState, getInternalMixinTarget(), pos);
        }
    }

    @Inject(
            method = "setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;II)Z",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/Level;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;",
                    ordinal = 0
            )
    )
    public void assortedlib_onSetBlockStateDoLightEngineUpdate(final class_2338 pos, final class_2680 state, final int flags, final int recursionLeft, final CallbackInfoReturnable<Boolean> cir) {
        final class_2680 newState = this.method_8320(pos);

        int oldOpacity = previousState.method_26193(getInternalMixinTarget(), pos);

        int newLight = newState.method_26213();
        int newOpacity = newState.method_26193(getInternalMixinTarget(), pos);

        if (newState.method_26204() instanceof IBlockLightEmission extraProperties) {
            newLight = extraProperties.getLightEmission(newState, getInternalMixinTarget(), pos);
        }


        if ((flags & 128) == 0 && previousState != newState && (newOpacity != oldOpacity || newLight != oldLight || previousState.method_26211() || newState.method_26211())) {
            getInternalMixinTarget().method_16107().method_15396("queueCheckLight");
            this.method_8398().method_12130().method_15513(pos);
            getInternalMixinTarget().method_16107().method_15407();
        }
    }
}
