package com.grim3212.assorted.lib.mixin.world.level;

import com.grim3212.assorted.lib.core.block.IBlockCanHarvest;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4970.class)
public abstract class BlockBehaviourWorldlyBlockMixin {

    @Inject(
            method = "getDestroyProgress",
            at = @At(
                    value = "HEAD"
            ),
            cancellable = true
    )
    public void assortedlib_handleWorldlyBreakableCondition(final class_2680 state, final class_1657 player, final class_1922 level, final class_2338 pos, final CallbackInfoReturnable<Float> cir) {
        if (state.method_26204() instanceof IBlockCanHarvest extraProperties) {
            float f = state.method_26214(level, pos);
            if (f == -1.0F) {
                cir.setReturnValue(0.0F);
            } else {
                int i = extraProperties.canHarvestBlock(state, level, pos, player) ? 30 : 100;
                cir.setReturnValue(player.method_7351(state) / f / (float) i);
            }
        }
    }
}
