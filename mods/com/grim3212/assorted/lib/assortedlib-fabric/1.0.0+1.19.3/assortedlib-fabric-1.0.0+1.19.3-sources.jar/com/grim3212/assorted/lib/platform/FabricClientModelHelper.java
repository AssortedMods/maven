package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.client.model.IModelBakeryAccessor;
import com.grim3212.assorted.lib.client.model.baked.IDataAwareBakedModel;
import com.grim3212.assorted.lib.client.model.data.*;
import com.grim3212.assorted.lib.client.model.loader.FabricBakedModelDelegate;
import com.grim3212.assorted.lib.platform.services.IClientModelHelper;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;
import java.util.Collections;
import net.minecraft.class_1087;
import net.minecraft.class_1100;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_4696;
import net.minecraft.class_4722;
import net.minecraft.class_5819;

public class FabricClientModelHelper implements IClientModelHelper {
    @Override
    public void requestModelDataRefresh(class_2586 blockEntity) {
        // NO-OP
    }

    private static final IBlockModelData EMPTY = new ModelDataBuilder().build();

    @Override
    public IBlockModelData empty() {
        return EMPTY;
    }

    @Override
    public @NotNull IModelDataBuilder createNewModelDataBuilder() {
        return new ModelDataBuilder();
    }

    @Override
    public @NotNull <T> IModelDataKey<T> createNewModelDataKey() {
        return new ModelDataKey<>();
    }

    @Override
    public class_1100 getUnbakedModel(class_2960 unbakedModel) {
        final IModelBakeryAccessor accessor = (IModelBakeryAccessor) class_310.method_1551().method_1554();
        return accessor.getModelBakery().method_4726(unbakedModel);
    }

    @Override
    public class_1087 adaptToPlatform(class_1087 bakedModel) {
        if (bakedModel instanceof FabricBakedModelDelegate) {
            return bakedModel;
        }

        return new FabricBakedModelDelegate(bakedModel);
    }

    @Override
    public boolean canRenderInType(final class_2680 blockState, final class_1921 renderType) {
        return class_4696.method_23679(blockState) == renderType;
    }

    @Override
    public boolean canRenderInType(final class_3610 fluidState, final class_1921 renderType) {
        return class_4696.method_23680(fluidState) == renderType;
    }

    @Override
    public @NotNull Collection<class_1921> getRenderTypesFor(final class_1087 model, final class_2680 state, final class_5819 rand, final IBlockModelData data) {
        return Collections.singletonList(class_4696.method_23679(state));
    }

    @Override
    public @NotNull Collection<class_1921> getRenderTypesFor(class_1087 model, class_1799 stack, boolean isFabulous) {
        if (stack.method_7909() instanceof class_1747 blockItem) {
            final Collection<class_1921> renderTypes;
            if (model instanceof IDataAwareBakedModel dataAwareBakedModel) {
                renderTypes = dataAwareBakedModel.getSupportedRenderTypes(blockItem.method_7711().method_9564(), class_5819.method_43049(42), IBlockModelData.empty());
            } else {
                renderTypes = getRenderTypesFor(model, blockItem.method_7711().method_9564(), class_5819.method_43049(42), IBlockModelData.empty());
            }
            if (renderTypes.contains(class_1921.method_23583())) {
                return Collections.singletonList(isFabulous || !class_310.method_29611() ? class_4722.method_24076() : class_4722.method_29382());
            }
            return Collections.singletonList(class_4722.method_24074());
        }
        return Collections.singletonList(isFabulous ? class_4722.method_24076() : class_4722.method_29382());
    }

    @Override
    public class_1921 getItemUnlitUnsortedTranslucentRenderType() {
        return class_1921.method_23577();
    }

    @Override
    public class_1921 getItemUnsortedTranslucentRenderType() {
        return class_1921.method_23577();
    }
}
