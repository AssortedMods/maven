package com.grim3212.assorted.lib.mixin.world.level;

import com.grim3212.assorted.lib.core.block.IBlockLightEmission;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1922.class)
public interface BlockGetterWorldlyBlockMixin {

    @Shadow
    public abstract class_2680 getBlockState(class_2338 pos);

    @Inject(method = "getLightEmission(Lnet/minecraft/core/BlockPos;)I", at = @At("HEAD"), cancellable = true)
    public default void assortedlib_onGetLightEmission(final class_2338 pos, final CallbackInfoReturnable<Integer> cir) {
        final class_2680 blockState = getBlockState(pos);
        if (blockState.method_26204() instanceof IBlockLightEmission extraProperties) {
            cir.setReturnValue(extraProperties.getLightEmission(blockState, (class_1922) this, pos));
        }
    }
}
