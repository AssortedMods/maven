package com.grim3212.assorted.lib.platform;

import com.grim3212.assorted.lib.registry.ILoaderRegistry;
import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

public class FabricRegistryWrapper<T> implements ILoaderRegistry<T> {

    private final class_2378<T> registry;

    private FabricRegistryWrapper(class_2378<T> registry) {
        this.registry = registry;
    }

    public static <T> ILoaderRegistry<T> getRegistry(class_5321<? extends class_2378<T>> key) {
        class_2378<? extends class_2378<?>> rootRegistry = class_7923.field_41167;
        class_2378<?> registry = rootRegistry.method_10223(key.method_29177());
        if (registry == null) {
            throw new NullPointerException("Could not find registry for key: " + key);
        }
        ILoaderRegistry<?> registryWrapper = new FabricRegistryWrapper<>(registry);
        @SuppressWarnings("unchecked")
        ILoaderRegistry<T> castPlatformRegistry = (ILoaderRegistry<T>) registryWrapper;
        return castPlatformRegistry;
    }

    @Override
    public Stream<T> getValues() {
        return this.registry.method_10220();
    }

    @Override
    public Optional<T> getValue(class_2960 resourceLocation) {
        T t = this.registry.method_10223(resourceLocation);
        return Optional.ofNullable(t);
    }

    @Override
    public boolean containsKey(class_2960 resourceLocation) {
        return getValue(resourceLocation).isPresent();
    }

    @Override
    public boolean contains(T entry) {
        return this.registry.method_10221(entry) != null;
    }

    @Override
    public class_2960 getRegistryName(T entry) {
        return this.registry.method_10221(entry);
    }
}
